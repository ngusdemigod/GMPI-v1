<?php
/**
 * Admin Support Ticket Management
 * Bright Light Ministry Int'l Partners Portal
 */

session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Include admin config
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/database.php';

// Load SupportTicket model
require_once __DIR__ . '/../src/models/SupportTicket.php';

$db = Database::getInstance();
$ticketModel = new SupportTicket();

// Get action
$action = $_GET['action'] ?? 'list';
$ticketId = $_GET['id'] ?? null;

// Handle form submissions
$successMessage = '';
$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_status'])) {
        $ticketId = (int)$_POST['ticket_id'];
        $status = $_POST['status'];
        if ($ticketModel->updateStatus($ticketId, $status)) {
            $successMessage = 'Ticket status updated successfully.';
        } else {
            $errorMessage = 'Failed to update ticket status.';
        }
    } elseif (isset($_POST['add_response'])) {
        $ticketId = (int)$_POST['ticket_id'];
        $response = trim($_POST['response'] ?? '');
        $isInternal = isset($_POST['is_internal']);
        $adminId = $_SESSION['admin_id'];
        
        if (!empty($response)) {
            $ticketModel->addResponse($ticketId, $response, $adminId);
            $successMessage = 'Response added successfully.';
        } else {
            $errorMessage = 'Response cannot be empty.';
        }
    }
}

// Get filter
$statusFilter = $_GET['status'] ?? 'all';
$searchQuery = $_GET['search'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Support Tickets — Admin Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
  body { font-family: 'Inter', sans-serif; }
</style>
</head>
<body class="bg-gray-100">
<style>
/* Mobile sidebar support */
.sidebar-overlay {
    display: none; position: fixed; inset: 0;
    background: rgba(0,0,0,0.5); z-index: 40;
}
.sidebar-overlay.active { display: block; }
@media (max-width: 1024px) {
    .sidebar-mobile-hidden { transform: translateX(-100%); position: fixed !important;
        top: 0; bottom: 0; left: 0; z-index: 50; transition: transform 0.3s ease; }
    .sidebar-mobile-hidden.open { transform: translateX(0); }
    .mobile-hamburger-bar { display: flex !important; }
}
.mobile-hamburger-bar { display: none; align-items: center; gap: 12px;
    background: white; padding: 12px 16px; border-bottom: 1px solid #e5e7eb; }
.mobile-hamburger-bar button { background: none; border: none; font-size: 22px; cursor: pointer; color: #1f2937; }
</style>

<div class="flex h-screen">

<!-- Sidebar -->
<div id="sidebarWrapper">
<?php include 'includes/sidebar.php'; ?>
</div>

<!-- Overlay -->
<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSupportSidebar()"></div>

<!-- Main Content -->
<div class="flex-1 flex flex-col overflow-hidden">
<!-- Mobile top bar -->
<div class="mobile-hamburger-bar" id="mobileBar">
    <button onclick="toggleSupportSidebar()" aria-label="Menu">&#9776;</button>
    <span style="font-weight:600;color:#1f2937;">Admin Dashboard</span>
</div>

<!-- Top Bar -->
<?php include 'includes/topbar.php'; ?>

<!-- Main Content Area -->
<main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-6">

<?php if ($action === 'list'): ?>

  <!-- Page Header -->
  <div class="mb-6 flex items-center justify-between">
    <div>
      <h1 class="text-2xl font-bold text-gray-800">Support Tickets</h1>
      <p class="text-gray-600 mt-1">Manage and respond to user support requests</p>
    </div>
    <a href="settings.php" class="px-4 py-2 bg-gold hover:bg-goldsoft text-deep font-semibold rounded-lg transition">
      Settings
    </a>
  </div>

  <!-- Stats Cards -->
  <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
    <div class="bg-white rounded-lg shadow p-4">
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm text-gray-600">Total Tickets</p>
          <p class="text-2xl font-bold text-gray-800"><?php 
            $stmt = $db->getConnection()->query("SELECT COUNT(*) as count FROM support_tickets");
            echo $stmt->fetch()['count'];
          ?></p>
        </div>
        <div class="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
          <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>
        </div>
      </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-4">
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm text-gray-600">Open</p>
          <p class="text-2xl font-bold text-red-600"><?php 
            $stmt = $db->getConnection()->query("SELECT COUNT(*) as count FROM support_tickets WHERE status='open'");
            echo $stmt->fetch()['count'];
          ?></p>
        </div>
        <div class="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
          <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
      </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-4">
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm text-gray-600">In Progress</p>
          <p class="text-2xl font-bold text-yellow-600"><?php 
            $stmt = $db->getConnection()->query("SELECT COUNT(*) as count FROM support_tickets WHERE status='in_progress'");
            echo $stmt->fetch()['count'];
          ?></p>
        </div>
        <div class="w-12 h-12 rounded-full bg-yellow-100 flex items-center justify-center">
          <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
      </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-4">
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm text-gray-600">Resolved</p>
          <p class="text-2xl font-bold text-green-600"><?php 
            $stmt = $db->getConnection()->query("SELECT COUNT(*) as count FROM support_tickets WHERE status='resolved'");
            echo $stmt->fetch()['count'];
          ?></p>
        </div>
        <div class="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
          <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
      </div>
    </div>
  </div>

  <!-- Filters -->
  <div class="bg-white rounded-lg shadow p-4 mb-6">
    <form method="GET" class="flex flex-wrap gap-4 items-end">
      <input type="hidden" name="action" value="list">
      
      <div class="flex-1 min-w-[200px]">
        <label class="block text-sm font-medium text-gray-700 mb-1">Search</label>
        <input type="text" name="search" 
          value="<?php echo htmlspecialchars($searchQuery); ?>"
          placeholder="Search tickets..."
          class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent outline-none"
        />
      </div>
      
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
        <select name="status" 
          class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent outline-none"
        >
          <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>All Status</option>
          <option value="open" <?php echo $statusFilter === 'open' ? 'selected' : ''; ?>>Open</option>
          <option value="in_progress" <?php echo $statusFilter === 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
          <option value="resolved" <?php echo $statusFilter === 'resolved' ? 'selected' : ''; ?>>Resolved</option>
          <option value="closed" <?php echo $statusFilter === 'closed' ? 'selected' : ''; ?>>Closed</option>
        </select>
      </div>
      
      <button type="submit" class="px-6 py-2 bg-gold hover:bg-goldsoft text-deep font-semibold rounded-lg transition">
        Filter
      </button>
    </form>
  </div>

  <!-- Tickets Table -->
  <div class="bg-white rounded-lg shadow overflow-hidden">
    <table class="w-full">
      <thead class="bg-gray-50 border-b border-gray-200">
        <tr>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject</th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-gray-200">
        <?php
        $where = [];
        $params = [];
        
        if ($statusFilter !== 'all') {
          $where[] = "status = :status";
          $params[':status'] = $statusFilter;
        }
        
        if (!empty($searchQuery)) {
          $where[] = "(subject LIKE :search OR message LIKE :search2 OR email LIKE :search3)";
          $params[':search'] = "%$searchQuery%";
          $params[':search2'] = "%$searchQuery%";
          $params[':search3'] = "%$searchQuery%";
        }
        
        $whereSql = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
        
        $sql = "SELECT st.*, u.first_name, u.last_name, u.email 
                FROM support_tickets st
                LEFT JOIN users u ON st.user_id = u.user_id
                $whereSql
                ORDER BY st.created_at DESC
                LIMIT 50";
        
        $stmt = $db->getConnection()->prepare($sql);
        foreach ($params as $key => $value) {
          $stmt->bindValue($key, $value);
        }
        $stmt->execute();
        $tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($tickets as $ticket):
          $statusColors = [
            'open' => 'bg-red-100 text-red-700',
            'in_progress' => 'bg-yellow-100 text-yellow-700',
            'resolved' => 'bg-green-100 text-green-700',
            'closed' => 'bg-gray-100 text-gray-700'
          ];
          $statusLabels = [
            'open' => 'Open',
            'in_progress' => 'In Progress',
            'resolved' => 'Resolved',
            'closed' => 'Closed'
          ];
        ?>
        <tr class="hover:bg-gray-50">
          <td class="px-6 py-4 text-sm text-gray-900">#<?php echo $ticket['ticket_id']; ?></td>
          <td class="px-6 py-4 text-sm text-gray-900"><?php echo htmlspecialchars($ticket['subject']); ?></td>
          <td class="px-6 py-4 text-sm text-gray-900">
            <?php echo $ticket['first_name'] ? htmlspecialchars($ticket['first_name'] . ' ' . $ticket['last_name']) : 'Anonymous'; ?>
            <?php if ($ticket['email']): ?>
            <br><span class="text-xs text-gray-500"><?php echo htmlspecialchars($ticket['email']); ?></span>
            <?php endif; ?>
          </td>
          <td class="px-6 py-4 text-sm text-gray-900"><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $ticket['category']))); ?></td>
          <td class="px-6 py-4">
            <span class="px-2 py-1 text-xs font-semibold rounded-full <?php echo $statusColors[$ticket['status']]; ?>">
              <?php echo $statusLabels[$ticket['status']]; ?>
            </span>
          </td>
          <td class="px-6 py-4 text-sm text-gray-900"><?php echo date('M j, Y', strtotime($ticket['created_at'])); ?></td>
          <td class="px-6 py-4 text-sm">
            <a href="?action=view&id=<?php echo $ticket['ticket_id']; ?>" 
              class="text-gold hover:text-goldsoft font-medium">View</a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

<?php elseif ($action === 'view' && $ticketId): ?>

  <?php
  $ticket = $ticketModel->getById($ticketId);
  if (!$ticket):
    header('Location:?action=list');
    exit;
  endif;
  
  $responses = $ticketModel->getResponses($ticketId);
  $attachments = $ticketModel->getAttachments($ticketId);
  $statusColors = [
    'open' => 'bg-red-100 text-red-700',
    'in_progress' => 'bg-yellow-100 text-yellow-700',
    'resolved' => 'bg-green-100 text-green-700',
    'closed' => 'bg-gray-100 text-gray-700'
  ];
  $statusLabels = [
    'open' => 'Open',
    'in_progress' => 'In Progress',
    'resolved' => 'Resolved',
    'closed' => 'Closed'
  ];
  ?>

  <!-- Page Header -->
  <div class="mb-6">
    <a href="?action=list" class="text-gold hover:underline flex items-center gap-1 mb-2">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
      Back to Tickets
    </a>
    <div class="flex items-start justify-between">
      <div>
        <h1 class="text-2xl font-bold text-gray-800"><?php echo htmlspecialchars($ticket['subject']); ?></h1>
        <p class="text-gray-600 mt-1">Ticket #<?php echo $ticket['ticket_id']; ?></p>
      </div>
      <form method="POST" class="flex items-center gap-2">
        <input type="hidden" name="ticket_id" value="<?php echo $ticket['ticket_id']; ?>">
        <select name="status" class="px-3 py-1.5 border border-gray-300 rounded-lg text-sm">
          <option value="open" <?php echo $ticket['status'] === 'open' ? 'selected' : ''; ?>>Open</option>
          <option value="in_progress" <?php echo $ticket['status'] === 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
          <option value="resolved" <?php echo $ticket['status'] === 'resolved' ? 'selected' : ''; ?>>Resolved</option>
          <option value="closed" <?php echo $ticket['status'] === 'closed' ? 'selected' : ''; ?>>Closed</option>
        </select>
        <button type="submit" name="update_status" class="px-4 py-1.5 bg-gold hover:bg-goldsoft text-deep font-semibold rounded-lg text-sm transition">
          Update Status
        </button>
      </form>
    </div>
  </div>

  <!-- Ticket Details -->
  <div class="grid md:grid-cols-3 gap-6">
    
    <!-- Left Column: Ticket Info -->
    <div class="md:col-span-2 space-y-6">
      
      <!-- User Info -->
      <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">User Information</h3>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <p class="text-sm text-gray-600">Name</p>
            <p class="font-medium"><?php echo $ticket['first_name'] ? htmlspecialchars($ticket['first_name'] . ' ' . $ticket['last_name']) : 'Anonymous'; ?></p>
          </div>
          <div>
            <p class="text-sm text-gray-600">Email</p>
            <p class="font-medium"><?php echo $ticket['email'] ? htmlspecialchars($ticket['email']) : 'N/A'; ?></p>
          </div>
          <div>
            <p class="text-sm text-gray-600">Category</p>
            <p class="font-medium"><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $ticket['category']))); ?></p>
          </div>
          <div>
            <p class="text-sm text-gray-600">Created</p>
            <p class="font-medium"><?php echo date('M j, Y g:i A', strtotime($ticket['created_at'])); ?></p>
          </div>
        </div>
      </div>

      <!-- Message -->
      <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Message</h3>
        <div class="bg-gray-50 rounded-lg p-4">
          <p class="text-gray-800 whitespace-pre-wrap"><?php echo htmlspecialchars($ticket['message']); ?></p>
        </div>
      </div>

      <!-- Attachments -->
      <?php if (!empty($attachments)): ?>
      <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Attachments</h3>
        <ul class="space-y-2">
          <?php foreach ($attachments as $att): ?>
          <li class="flex items-center gap-3">
            <svg class="w-5 h-5 text-gold" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"/></svg>
            <span class="text-gray-800"><?php echo htmlspecialchars($att['file_name']); ?></span>
            <span class="text-xs text-gray-500"><?php echo date('M j, Y', strtotime($att['uploaded_at'])); ?></span>
          </li>
          <?php endforeach; ?>
        </ul>
      </div>
      <?php endif; ?>

      <!-- Responses -->
      <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Responses</h3>
        
        <?php if (!empty($responses)): ?>
        <div class="space-y-4 mb-6">
          <?php foreach ($responses as $resp): ?>
          <div class="border-l-4 <?php echo $resp['is_internal'] ? 'border-gray-300' : 'border-gold'; ?> pl-4">
            <div class="flex items-center justify-between mb-2">
              <span class="text-sm font-medium">
                <?php echo $resp['is_internal'] ? 'Internal Note' : htmlspecialchars($resp['first_name'] . ' ' . $resp['last_name']); ?>
              </span>
              <span class="text-xs text-gray-500"><?php echo date('M j, Y g:i A', strtotime($resp['created_at'])); ?></span>
            </div>
            <div class="bg-gray-50 rounded-lg p-3">
              <p class="text-gray-800 whitespace-pre-wrap"><?php echo htmlspecialchars($resp['response']); ?></p>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php else: ?>
        <p class="text-gray-500 text-sm">No responses yet.</p>
        <?php endif; ?>

        <!-- Add Response Form -->
        <form method="POST" class="mt-6">
          <input type="hidden" name="ticket_id" value="<?php echo $ticket['ticket_id']; ?>">
          <div class="mb-3">
            <label class="block text-sm font-medium text-gray-700 mb-2">Add Response</label>
            <textarea name="response" rows="4" 
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent outline-none"
              placeholder="Type your response here..."></textarea>
          </div>
          <div class="flex items-center gap-3">
            <label class="flex items-center gap-2">
              <input type="checkbox" name="is_internal" class="rounded border-gray-300">
              <span class="text-sm text-gray-700">Internal note (not visible to user)</span>
            </label>
            <button type="submit" name="add_response" class="px-4 py-2 bg-gold hover:bg-goldsoft text-deep font-semibold rounded-lg transition">
              Send Response
            </button>
          </div>
        </form>
      </div>

    </div>

    <!-- Right Column: Status -->
    <div class="space-y-6">
      
      <!-- Status Card -->
      <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Status</h3>
        <div class="space-y-3">
          <div class="flex items-center gap-3">
            <span class="px-3 py-1 text-sm font-semibold rounded-full <?php echo $statusColors[$ticket['status']]; ?>">
              <?php echo $statusLabels[$ticket['status']]; ?>
            </span>
          </div>
          <div class="text-sm text-gray-600">
            <p>Created: <?php echo date('M j, Y', strtotime($ticket['created_at'])); ?></p>
            <p>Updated: <?php echo date('M j, Y', strtotime($ticket['updated_at'])); ?></p>
          </div>
        </div>
      </div>

      <!-- Quick Actions -->
      <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h3>
        <div class="space-y-2">
          <button onclick="window.location.href='?action=view&id=<?php echo $ticket['ticket_id']; ?>&mark=read'" 
            class="w-full px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition text-sm">
            Mark as Read
          </button>
          <button onclick="if(confirm('Mark this ticket as resolved?')) window.location.href='?action=view&id=<?php echo $ticket['ticket_id']; ?>&resolve=1'" 
            class="w-full px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition text-sm">
            Mark as Resolved
          </button>
          <button onclick="if(confirm('Delete this ticket?')) window.location.href='?action=view&id=<?php echo $ticket['ticket_id']; ?>&delete=1'" 
            class="w-full px-4 py-2 border border-red-300 text-red-600 rounded-lg hover:bg-red-50 transition text-sm">
            Delete Ticket
          </button>
        </div>
      </div>

    </div>

  </div>

<?php endif; ?>

</main>

</div>
</div>

<script>
function toggleSupportSidebar() {
    var sidebar = document.querySelector('#sidebarWrapper > aside, #sidebarWrapper > div');
    var overlay = document.getElementById('sidebarOverlay');
    if (sidebar) {
        sidebar.classList.toggle('sidebar-mobile-hidden');
        sidebar.classList.toggle('open');
        overlay.classList.toggle('active');
    }
}
function closeSupportSidebar() {
    var sidebar = document.querySelector('#sidebarWrapper > aside, #sidebarWrapper > div');
    var overlay = document.getElementById('sidebarOverlay');
    if (sidebar) {
        sidebar.classList.add('sidebar-mobile-hidden');
        sidebar.classList.remove('open');
        overlay.classList.remove('active');
    }
}
// On load, tag the sidebar for mobile
if (window.innerWidth <= 1024) {
    var sidebar = document.querySelector('#sidebarWrapper > aside, #sidebarWrapper > div');
    if (sidebar) sidebar.classList.add('sidebar-mobile-hidden');
}
window.addEventListener('resize', function() {
    var sidebar = document.querySelector('#sidebarWrapper > aside, #sidebarWrapper > div');
    if (!sidebar) return;
    if (window.innerWidth > 1024) {
        sidebar.classList.remove('sidebar-mobile-hidden', 'open');
        document.getElementById('sidebarOverlay').classList.remove('active');
    } else {
        if (!sidebar.classList.contains('open')) {
            sidebar.classList.add('sidebar-mobile-hidden');
        }
    }
});
</script>
</body>
</html>