<?php
/**
 * Payment Plans Management Page
 * Church Financial Partnership System
 */

require_once __DIR__ . '/includes/config.php';

// Require authentication
$admin = requireAdmin();

$db = Database::getInstance();
$action = $_GET['action'] ?? 'list';
$planId = $_GET['id'] ?? null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    try {
        if ($action === 'create' || $action === 'edit') {
            $name = sanitizeInput($_POST['name'] ?? '');
            $description = sanitizeInput($_POST['description'] ?? '');
            $amount = floatval($_POST['amount'] ?? 0);
            $minAmount = floatval($_POST['min_amount'] ?? 0);
            $maxAmount = $_POST['max_amount'] !== '' ? floatval($_POST['max_amount']) : null;
            $frequency = sanitizeInput($_POST['frequency'] ?? '');
            $paystackPlanCode = sanitizeInput($_POST['paystack_plan_code'] ?? '');
            $isActive = isset($_POST['is_active']) ? true : false;
            $isPaused = isset($_POST['is_paused']) ? true : false;
            $maxSubscriptions = $_POST['max_subscriptions'] !== '' ? intval($_POST['max_subscriptions']) : null;
            $displayOrder = intval($_POST['display_order'] ?? 0);
            $icon = sanitizeInput($_POST['icon'] ?? 'star');
            $colorCode = sanitizeInput($_POST['color_code'] ?? '#D4AF37');
            
            if (empty($name) || empty($frequency)) {
                throw new Exception('Plan name and frequency are required');
            }
            
            if ($action === 'create') {
                $db->execute(
                    "INSERT INTO payment_plans (name, description, amount, min_amount, max_amount, currency, frequency, paystack_plan_code, is_active, is_paused, max_subscriptions, display_order, icon, color_code)
                     VALUES (:name, :description, :amount, :min_amount, :max_amount, 'USD', :frequency, :paystack_plan_code, :is_active, :is_paused, :max_subscriptions, :display_order, :icon, :color_code)",
                    [
                        'name' => $name,
                        'description' => $description,
                        'amount' => $amount,
                        'min_amount' => $minAmount,
                        'max_amount' => $maxAmount,
                        'frequency' => $frequency,
                        'paystack_plan_code' => $paystackPlanCode,
                        'is_active' => $isActive,
                        'is_paused' => $isPaused,
                        'max_subscriptions' => $maxSubscriptions,
                        'display_order' => $displayOrder,
                        'icon' => $icon,
                        'color_code' => $colorCode
                    ]
                );
                
                $planId = $db->lastInsertId();
                logAdminAction($admin['admin_id'], 'PLAN_CREATE', 'plan', $planId, $name);
                
                $success = 'Payment plan created successfully';
                $action = 'edit';
            } else {
                $db->execute(
                    "UPDATE payment_plans 
                     SET name = :name, description = :description, amount = :amount, min_amount = :min_amount, max_amount = :max_amount, frequency = :frequency,
                         paystack_plan_code = :paystack_plan_code, is_active = :is_active, is_paused = :is_paused,
                         max_subscriptions = :max_subscriptions, display_order = :display_order, icon = :icon, color_code = :color_code
                     WHERE plan_id = :plan_id",
                    [
                        'name' => $name,
                        'description' => $description,
                        'amount' => $amount,
                        'min_amount' => $minAmount,
                        'max_amount' => $maxAmount,
                        'frequency' => $frequency,
                        'paystack_plan_code' => $paystackPlanCode,
                        'is_active' => $isActive,
                        'is_paused' => $isPaused,
                        'max_subscriptions' => $maxSubscriptions,
                        'display_order' => $displayOrder,
                        'icon' => $icon,
                        'color_code' => $colorCode,
                        'plan_id' => $planId
                    ]
                );
                
                logAdminAction($admin['admin_id'], 'PLAN_UPDATE', 'plan', $planId, $name);
                
                $success = 'Payment plan updated successfully';
            }
        } elseif ($action === 'delete') {
            $plan = $db->fetchOne("SELECT name FROM payment_plans WHERE plan_id = :id", ['id' => $planId]);
            if ($plan) {
                // Check if plan has active subscribers
                $subscribers = $db->fetchOne(
                    "SELECT COUNT(*) as count FROM pledges WHERE frequency = (SELECT frequency FROM payment_plans WHERE plan_id = :id)",
                    ['id' => $planId]
                );
                
                if ($subscribers['count'] > 0) {
                    throw new Exception('Cannot delete plan with active subscribers. Pause the plan instead.');
                }
                
                $db->execute("DELETE FROM payment_plans WHERE plan_id = :id", ['id' => $planId]);
                logAdminAction($admin['admin_id'], 'PLAN_DELETE', 'plan', $planId, $plan['name']);
                $success = 'Payment plan deleted successfully';
                $action = 'list';
            }
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Get plan data
$plan = null;
$planSubscribers = [];
if ($action === 'edit' && $planId) {
    $plan = $db->fetchOne(
        "SELECT * FROM payment_plans WHERE plan_id = :id",
        ['id' => $planId]
    );
    
    if ($plan) {
        $planSubscribers = $db->fetchAll(
            "SELECT u.user_id, u.email, u.first_name, u.last_name, p.total_amount, p.frequency, p.start_date
             FROM pledges p
             INNER JOIN users u ON p.user_id = u.user_id
             WHERE p.frequency = :frequency AND p.is_active = TRUE
             LIMIT 20",
            ['frequency' => $plan['frequency']]
        );
    }
}

// Get plans list
$plans = $db->fetchAll(
    "SELECT *, 
            (SELECT COUNT(*) FROM pledges WHERE frequency = payment_plans.frequency AND is_active = TRUE) as active_subscribers
     FROM payment_plans
     ORDER BY display_order, plan_id"
);

// Get plan statistics
$totalPlans = count($plans);
$activePlans = count(array_filter($plans, fn($p) => $p['is_active']));
$pausedPlans = count(array_filter($plans, fn($p) => $p['is_paused']));
$totalSubscribers = array_sum(array_column($plans, 'active_subscribers'));

// Get recent activity
$recentActivity = $db->fetchAll(
    "SELECT p.*, u.first_name, u.last_name
     FROM pledges p
     INNER JOIN users u ON p.user_id = u.user_id
     WHERE p.is_active = TRUE
     ORDER BY p.created_at DESC
     LIMIT 5"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Plans - Admin Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;0,9..144,700;1,9..144,500&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="form-styles.css" rel="stylesheet">
    <style>
        :root {
            --gold: #C9A24B;
            --gold-light: #E7D9B4;
            --gold-dark: #A8863A;
            --dark: #0F1B2D;
            --deep: #122137;
            --cream: #FAF6EF;
            --cream-light: #F5F0E8;
            --text-primary: #0F1B2D;
            --text-secondary: rgba(15, 27, 45, 0.55);
            --text-muted: rgba(15, 27, 45, 0.4);
            --success: #28a745;
            --warning: #ffc107;
            --danger: #dc3545;
            --info: #17a2b8;
            --radius-sm: 14px;
            --radius-md: 14px;
            --radius-lg: 24px;
            --shadow-sm: 0 2px 4px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 12px rgba(0,0,0,0.1);
            --shadow-lg: 0 8px 24px rgba(0,0,0,0.15);
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Inter', sans-serif; 
            background: #FAF6EF; 
            color: #0F1B2D;
            min-height: 100vh;
        }
        h1, h2, h3, h4 { font-family: 'Fraunces', serif; }
        .font-serif { font-family: 'Fraunces', serif; }
        
        .layout { display: flex; min-height: 100vh; }
        
        .sidebar {
            position: fixed; left: 0; top: 0; bottom: 0; width: 280px;
            background: var(--dark); color: white; padding: 24px 0; overflow-y: auto; z-index: 1000;
        }
        .sidebar-header { padding: 0 24px 24px; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar-logo { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
        .sidebar-logo-icon { width: 40px; height: 40px; background: var(--gold); border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 20px; color: var(--dark); }
        .sidebar-logo-text { font-family: 'Playfair Display', serif; font-size: 14px; }
        .sidebar-logo-text span { display: block; font-size: 10px; font-family: 'Inter', sans-serif; color: rgba(255,255,255,0.6); }
        .admin-info { display: flex; align-items: center; gap: 12px; padding: 16px 24px; background: rgba(255,255,255,0.05); border-radius: 12px; margin: 16px 12px; }
        .admin-avatar { width: 40px; height: 40px; background: var(--gold); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; color: var(--dark); }
        .admin-details { flex: 1; }
        .admin-name { font-size: 12px; font-weight: 500; }
        .admin-email { font-size: 10px; color: rgba(255,255,255,0.5); }
        .nav-menu { list-style: none; padding: 0 12px; }
        .nav-item { margin: 4px 0; }
        .nav-link { display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: rgba(255,255,255,0.7); text-decoration: none; border-radius: 12px; transition: all 0.2s; font-size: 14px; }
        .nav-link:hover, .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .nav-link i { width: 20px; text-align: center; }
        .nav-section { padding: 16px 12px 8px; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; color: rgba(255,255,255,0.4); }
        .sidebar-footer { position: absolute; bottom: 0; left: 0; right: 0; padding: 16px 12px; border-top: 1px solid rgba(255,255,255,0.1); }
        .sidebar-footer .nav-link:hover { color: var(--danger); }
        
        .main-content { margin-left: 280px; flex: 1; padding: 32px; }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; }
        .page-title h1 { font-size: 28px; color: var(--dark); margin-bottom: 4px; }
        .page-title p { color: var(--text-secondary); font-size: 14px; }
        .page-actions { display: flex; gap: 12px; }
        
        .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border-radius: 6px; font-size: 14px; font-weight: 500; text-decoration: none; cursor: pointer; border: none; transition: all 0.2s; }
        .btn-primary { background: var(--gold); color: var(--dark); }
        .btn-primary:hover { background: var(--gold-dark); }
        .btn-secondary { background: white; color: var(--text-primary); border: 1px solid rgba(0,0,0,0.1); }
        .btn-secondary:hover { background: var(--cream-light); }
        .btn-danger { background: var(--danger); color: white; }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        .btn-icon { padding: 8px; }
        
        .card { background: white; border-radius: 16px; box-shadow: var(--shadow-sm); overflow: hidden; }
        .card-header { display: flex; justify-content: space-between; align-items: center; padding: 20px 24px; border-bottom: 1px solid rgba(0,0,0,0.05); }
        .card-title { font-size: 18px; color: var(--dark); }
        .card-body { padding: 24px; }
        
        .metrics-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px; margin-bottom: 32px; }
        .metric-card { background: white; border-radius: 16px; padding: 24px; box-shadow: var(--shadow-sm); }
        .metric-title { font-size: 13px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }
        .metric-value { font-size: 32px; font-weight: 700; color: var(--dark); }
        .metric-subtitle { font-size: 12px; color: var(--text-muted); margin-top: 4px; }
        
        .plan-card { background: var(--cream-light); border-radius: 12px; padding: 20px; border: 1px solid rgba(0,0,0,0.05); transition: all 0.2s; }
        .plan-card:hover { box-shadow: var(--shadow-md); transform: translateY(-2px); }
        .plan-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px; }
        .plan-icon { width: 48px; height: 48px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 24px; }
        .plan-title { font-size: 18px; font-weight: 600; margin-bottom: 8px; }
        .plan-description { color: var(--text-secondary); font-size: 14px; margin-bottom: 16px; }
        .plan-amount { font-size: 32px; font-weight: 700; color: var(--gold-dark); }
        .plan-frequency { font-size: 14px; color: var(--text-muted); }
        .plan-stats { display: flex; gap: 24px; margin-top: 16px; padding-top: 16px; border-top: 1px solid rgba(0,0,0,0.1); }
        .plan-stat { text-align: center; }
        .plan-stat-value { font-size: 18px; font-weight: 600; color: var(--dark); }
        .plan-stat-label { font-size: 12px; color: var(--text-muted); }
        .plan-status { padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 500; }
        .plan-status.active { background: rgba(40, 167, 69, 0.1); color: var(--success); }
        .plan-status.paused { background: rgba(255, 193, 7, 0.1); color: #b7950b; }
        .plan-status.inactive { background: rgba(108, 117, 125, 0.1); color: var(--text-muted); }
        
        .form-group { margin-bottom: 20px; }
        .form-label { display: block; font-size: 14px; font-weight: 500; color: var(--text-primary); margin-bottom: 8px; }
        .form-input, .form-select, .form-textarea { width: 100%; padding: 12px 16px; border: 1px solid rgba(0,0,0,0.1); border-radius: 6px; font-size: 14px; }
        .form-input:focus, .form-select:focus, .form-textarea:focus { outline: none; border-color: var(--gold); box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1); }
        .form-textarea { min-height: 100px; resize: vertical; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        
        .alert { padding: 14px 18px; border-radius: 6px; margin-bottom: 20px; }
        .alert-success { background: rgba(40, 167, 69, 0.1); color: var(--success); border: 1px solid rgba(40, 167, 69, 0.3); }
        .alert-error { background: rgba(220, 53, 69, 0.1); color: var(--danger); border: 1px solid rgba(220, 53, 69, 0.3); }
        
        .subscriber-list { margin-top: 24px; padding-top: 24px; border-top: 1px solid rgba(0,0,0,0.1); }
        .subscriber-item { display: flex; justify-content: space-between; align-items: center; padding: 12px; background: var(--cream-light); border-radius: 8px; margin-bottom: 8px; }
        
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0; }
        }
        @media (max-width: 768px) {
            .form-row { grid-template-columns: 1fr; }
            .metrics-grid { grid-template-columns: repeat(2, 1fr); }
        }
    
        /* ── Responsive sidebar & hamburger ── */
        .sidebar { transition: transform 0.3s ease; }
        .sidebar.open { transform: translateX(0) !important; }

        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999;
        }
        .sidebar-overlay.active { display: block; }

        .hamburger {
            display: none;
            background: none;
            border: none;
            font-size: 22px;
            color: var(--dark, #0F1B2D);
            cursor: pointer;
            padding: 6px 10px;
            border-radius: 6px;
            line-height: 1;
            flex-shrink: 0;
        }
        .hamburger:hover { background: rgba(0,0,0,0.05); }

        .page-header-left {
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }

        @media (max-width: 1024px) {
            .hamburger { display: flex; align-items: center; justify-content: center; }
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0 !important; }
        }

        @media (max-width: 768px) {
            .main-content { padding: 16px !important; }
            .page-header { flex-wrap: wrap; gap: 12px; margin-bottom: 20px !important; }
            .page-actions { width: 100%; justify-content: flex-end; }
            .page-title h1 { font-size: 22px !important; }
            .metrics-grid { grid-template-columns: repeat(2, 1fr) !important; gap: 12px !important; }
            .filter-grid { grid-template-columns: 1fr !important; }
            .form-row { grid-template-columns: 1fr !important; }
            .metric-value { font-size: 24px !important; }
            .card-header, .card-body { padding: 16px !important; }
            .modal { width: 95% !important; border-radius: 12px !important; }
            .table-container { overflow-x: auto; }
            .btn-label { display: none; }
        }

        @media (max-width: 480px) {
            .metrics-grid { grid-template-columns: 1fr !important; }
            .main-content { padding: 12px !important; }
            .page-title h1 { font-size: 19px !important; }
        }

    </style>
</head>
<body>
    <div class="layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <div class="sidebar-logo-icon">✝</div>
                    <div class="sidebar-logo-text">
                        Bright Light Ministry Int'l
                        <span>Admin Dashboard</span>
                    </div>
                </div>
                <div class="admin-info">
                    <div class="admin-avatar"><?php echo strtoupper(substr($admin['first_name'], 0, 1) . substr($admin['last_name'], 0, 1)); ?></div>
                    <div class="admin-details">
                        <div class="admin-name"><?php echo e($admin['first_name'] . ' ' . $admin['last_name']); ?></div>
                        <div class="admin-email"><?php echo e($admin['email']); ?></div>
                    </div>
                </div>
            </div>
            <nav>
                <ul class="nav-menu">
                    <li class="nav-section">Dashboard</li>
                    <li class="nav-item"><a href="index.php" class="nav-link"><i class="fas fa-home"></i><span>Overview</span></a></li>
                    <li class="nav-section">Management</li>
                    <li class="nav-item"><a href="projects.php" class="nav-link"><i class="fas fa-project-diagram"></i><span>Projects</span></a></li>
                    <li class="nav-item"><a href="users.php" class="nav-link"><i class="fas fa-users"></i><span>Users</span></a></li>
                    <li class="nav-item"><a href="transactions.php" class="nav-link"><i class="fas fa-exchange-alt"></i><span>Transactions</span></a></li>
                    <li class="nav-item"><a href="plans.php" class="nav-link active"><i class="fas fa-tags"></i><span>Payment Plans</span></a></li>
                    <li class="nav-item"><a href="partners.php" class="nav-link"><i class="fas fa-handshake"></i><span>Partners</span></a></li>
                    <li class="nav-section">Administration</li>
                    <li class="nav-item"><a href="admin-members.php" class="nav-link"><i class="fas fa-user-shield"></i><span>Admin Members</span></a></li>
                    <li class="nav-item"><a href="audit-logs.php" class="nav-link"><i class="fas fa-history"></i><span>Audit Logs</span></a></li>
                    <li class="sidebar-footer">
                        <ul class="nav-menu">
                            <li class="nav-item"><a href="logout.php" class="nav-link"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <div class="page-header">
                <div class="page-header-left">
                    <button class="hamburger" onclick="toggleSidebar()" aria-label="Toggle menu"><i class="fas fa-bars"></i></button>
                    <div class="page-title">
                        <h1>Payment Plans</h1>
                        <p>Manage recurring payment plans and subscription tiers</p>
                    </div>
                </div>
                <div class="page-actions">
                    <a href="plans.php?action=create" class="btn btn-primary">
                        <i class="fas fa-plus"></i><span class="btn-label"> New Plan</span>
                    </a>
                </div>
            </div>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo e($success); ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo e($error); ?></div>
            <?php endif; ?>
            
            <?php if ($action === 'edit' && $plan): ?>
                <!-- Edit Plan -->
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Edit Payment Plan</h2>
                        <a href="plans.php" class="btn btn-secondary btn-sm">Back to List</a>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label" for="name">Plan Name *</label>
                                    <input type="text" id="name" name="name" class="form-input" value="<?php echo e($plan['name']); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="frequency">Frequency *</label>
                                    <select id="frequency" name="frequency" class="form-select" required>
                                        <option value="One-time" <?php echo $plan['frequency'] === 'One-time' ? 'selected' : ''; ?>>One-time</option>
                                        <option value="Weekly" <?php echo $plan['frequency'] === 'Weekly' ? 'selected' : ''; ?>>Weekly</option>
                                        <option value="Monthly" <?php echo $plan['frequency'] === 'Monthly' ? 'selected' : ''; ?>>Monthly</option>
                                        <option value="Annually" <?php echo $plan['frequency'] === 'Annually' ? 'selected' : ''; ?>>Annually</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="description">Description</label>
                                <textarea id="description" name="description" class="form-textarea"><?php echo e($plan['description']); ?></textarea>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label" for="amount">Amount (USD) *</label>
                                    <input type="number" id="amount" name="amount" class="form-input" value="<?php echo e($plan['amount']); ?>" step="0.01" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="display_order">Display Order</label>
                                    <input type="number" id="display_order" name="display_order" class="form-input" value="<?php echo e($plan['display_order']); ?>">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label" for="min_amount">Minimum Amount (USD)</label>
                                    <input type="number" id="min_amount" name="min_amount" class="form-input" value="<?php echo e($plan['min_amount'] ?? 0); ?>" step="0.01" placeholder="0">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="max_amount">Maximum Amount (USD)</label>
                                    <input type="number" id="max_amount" name="max_amount" class="form-input" value="<?php echo e($plan['max_amount'] ?? ''); ?>" step="0.01" placeholder="Leave empty for unlimited">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label" for="paystack_plan_code">Paystack Plan Code</label>
                                    <input type="text" id="paystack_plan_code" name="paystack_plan_code" class="form-input" value="<?php echo e($plan['paystack_plan_code']); ?>" placeholder="plan_...">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="icon">Icon</label>
                                    <select id="icon" name="icon" class="form-select">
                                        <option value="star" <?php echo $plan['icon'] === 'star' ? 'selected' : ''; ?>>Star</option>
                                        <option value="calendar" <?php echo $plan['icon'] === 'calendar' ? 'selected' : ''; ?>>Calendar</option>
                                        <option value="crown" <?php echo $plan['icon'] === 'crown' ? 'selected' : ''; ?>>Crown</option>
                                        <option value="gift" <?php echo $plan['icon'] === 'gift' ? 'selected' : ''; ?>>Gift</option>
                                        <option value="heart" <?php echo $plan['icon'] === 'heart' ? 'selected' : ''; ?>>Heart</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label" for="color_code">Color</label>
                                    <input type="color" id="color_code" name="color_code" class="form-input" value="<?php echo e($plan['color_code']); ?>" style="height: 48px; padding: 4px;">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Max Subscriptions</label>
                                    <input type="number" id="max_subscriptions" name="max_subscriptions" class="form-input" value="<?php echo $plan['max_subscriptions'] ?? ''; ?>" placeholder="Unlimited">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">
                                        <input type="checkbox" name="is_active" <?php echo $plan['is_active'] ? 'checked' : ''; ?>>
                                        <span style="margin-left: 8px;">Active</span>
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">
                                        <input type="checkbox" name="is_paused" <?php echo $plan['is_paused'] ? 'checked' : ''; ?>>
                                        <span style="margin-left: 8px;">Paused (prevent new subscriptions)</span>
                                    </label>
                                </div>
                            </div>
                            
                            <div style="display: flex; gap: 12px; margin-top: 24px;">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Save Changes
                                </button>
                                <a href="plans.php?action=delete&id=<?php echo $planId; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this plan?')">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </div>
                        </form>
                        
                        <!-- Subscribers -->
                        <?php if (!empty($planSubscribers)): ?>
                        <div class="subscriber-list">
                            <h3 style="font-size: 16px; margin-bottom: 16px;">Active Subscribers</h3>
                            <?php foreach ($planSubscribers as $subscriber): ?>
                                <div class="subscriber-item">
                                    <div>
                                        <strong><?php echo e($subscriber['first_name'] . ' ' . $subscriber['last_name']); ?></strong><br>
                                        <small style="color: var(--text-secondary);"><?php echo e($subscriber['email']); ?></small>
                                    </div>
                                    <div style="text-align: right;">
                                        <div style="font-weight: 600; color: var(--success);"><?php echo formatCurrency($subscriber['total_amount']); ?></div>
                                        <small style="color: var(--text-muted);"><?php echo formatDate($subscriber['start_date']); ?></small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
            <?php else: ?>
                <!-- Plans List -->
                <div class="metrics-grid">
                    <div class="metric-card">
                        <div class="metric-title">Total Plans</div>
                        <div class="metric-value"><?php echo number_format($totalPlans); ?></div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-title">Active Plans</div>
                        <div class="metric-value"><?php echo number_format($activePlans); ?></div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-title">Paused Plans</div>
                        <div class="metric-value"><?php echo number_format($pausedPlans); ?></div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-title">Total Subscribers</div>
                        <div class="metric-value"><?php echo number_format($totalSubscribers); ?></div>
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 24px;">
                    <?php foreach ($plans as $plan): 
                        $statusClass = $plan['is_paused'] ? 'paused' : ($plan['is_active'] ? 'active' : 'inactive');
                        $statusText = $plan['is_paused'] ? 'Paused' : ($plan['is_active'] ? 'Active' : 'Inactive');
                    ?>
                        <div class="plan-card" style="border-left: 4px solid <?php echo e($plan['color_code']); ?>;">
                            <div class="plan-header">
                                <div>
                                    <div class="plan-title"><?php echo e($plan['name']); ?></div>
                                    <div class="plan-description"><?php echo e(substr($plan['description'], 0, 80)); ?><?php echo strlen($plan['description']) > 80 ? '...' : ''; ?></div>
                                </div>
                                <span class="plan-status <?php echo $statusClass; ?>"><?php echo $statusText; ?></span>
                            </div>
                            <div style="display: flex; align-items: baseline; gap: 8px; margin-bottom: 16px;">
                                <span class="plan-amount"><?php echo formatCurrency($plan['amount']); ?></span>
                                <span class="plan-frequency"><?php echo e($plan['frequency']); ?></span>
                            </div>
                            <div class="plan-stats">
                                <div class="plan-stat">
                                    <div class="plan-stat-value"><?php echo number_format($plan['active_subscribers']); ?></div>
                                    <div class="plan-stat-label">Subscribers</div>
                                </div>
                                <div class="plan-stat">
                                    <div class="plan-stat-value"><?php echo $plan['is_paused'] ? 'Yes' : 'No'; ?></div>
                                    <div class="plan-stat-label">Paused</div>
                                </div>
                                <div class="plan-stat">
                                    <div class="plan-stat-value"><?php echo $plan['max_subscriptions'] ? number_format($plan['max_subscriptions']) : '∞'; ?></div>
                                    <div class="plan-stat-label">Max Limit</div>
                                </div>
                            </div>
                            <div style="margin-top: 16px; display: flex; gap: 8px;">
                                <a href="plans.php?action=edit&id=<?php echo $plan['plan_id']; ?>" class="btn btn-secondary btn-sm" style="flex: 1; justify-content: center;">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Recent Activity -->
                <div class="card" style="margin-top: 24px;">
                    <div class="card-header">
                        <h2 class="card-title">Recent Subscription Activity</h2>
                    </div>
                    <div class="card-body">
                        <?php if (empty($recentActivity)): ?>
                            <p style="color: var(--text-muted); text-align: center; padding: 24px;">No recent subscription activity</p>
                        <?php else: ?>
                            <div style="display: grid; gap: 12px;">
                                <?php foreach ($recentActivity as $activity): ?>
                                    <div class="subscriber-item">
                                        <div>
                                            <strong><?php echo e($activity['first_name'] . ' ' . $activity['last_name']); ?></strong>
                                            <br><small style="color: var(--text-secondary);"><?php echo e($activity['frequency']); ?> pledge</small>
                                        </div>
                                        <div style="text-align: right;">
                                            <div style="font-weight: 600; color: var(--success);"><?php echo formatCurrency($activity['total_amount']); ?></div>
                                            <small style="color: var(--text-muted);"><?php echo formatDate($activity['start_date']); ?></small>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <!-- Responsive sidebar JS -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>
    <script>
        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('open');
            document.getElementById('sidebarOverlay').classList.toggle('active');
        }
        function closeSidebar() {
            document.querySelector('.sidebar').classList.remove('open');
            document.getElementById('sidebarOverlay').classList.remove('active');
        }
        document.querySelectorAll('.nav-link').forEach(function(link) {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 1024) closeSidebar();
            });
        });
    </script>

</body>
</html>