<?php
/**
 * Projects Management Page
 * Church Financial Partnership System
 */

require_once __DIR__ . '/includes/config.php';

// Require authentication
$admin = requireAdmin();

$db = Database::getInstance();
$action = $_GET['action'] ?? 'list';
$projectId = $_GET['id'] ?? null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    // Get action from POST data for form submissions
    $formAction = $_POST['action'] ?? 'create';
    $formProjectId = $_POST['id'] ?? null;
    
    try {
        if ($formAction === 'create' || $formAction === 'edit') {
            $title = sanitizeInput($_POST['title'] ?? '');
            $slug = sanitizeInput($_POST['slug'] ?? '');
            $description = sanitizeInput($_POST['description'] ?? '');
            $shortDescription = sanitizeInput($_POST['short_description'] ?? '');
            $category = sanitizeInput($_POST['category'] ?? '');
            $projectType = sanitizeInput($_POST['project_type'] ?? '');
            $goalAmount = floatval($_POST['goal_amount'] ?? 0);
            $startingAmount = floatval($_POST['starting_amount'] ?? 0);
            $startDate = $_POST['start_date'] ?? null;
            $endDate = $_POST['end_date'] ?? null;
            $isActive = isset($_POST['is_active']) ? true : false;
            $displayOrder = intval($_POST['display_order'] ?? 0);
            $icon = sanitizeInput($_POST['icon'] ?? 'building');
            $accentColor = sanitizeInput($_POST['accent_color'] ?? 'deep');
            $visibility = sanitizeInput($_POST['visibility'] ?? 'public');
            $isFeatured = isset($_POST['is_featured']) ? true : false;
            $allowAnonymous = isset($_POST['allow_anonymous']) ? true : false;
            $minGift = floatval($_POST['min_gift'] ?? 0);
            $maxGift = floatval($_POST['max_gift'] ?? 0);
            $isTaxDeductible = isset($_POST['is_tax_deductible']) ? true : false;
            $isMatchingEnabled = isset($_POST['is_matching_enabled']) ? true : false;
            $matchRatio = sanitizeInput($_POST['match_ratio'] ?? '1:1');
            $matchCap = floatval($_POST['match_cap'] ?? 0);
            $matchSponsor = sanitizeInput($_POST['match_sponsor'] ?? '');
            $projectManager = sanitizeInput($_POST['project_manager'] ?? '');
            $launchMessage = sanitizeInput($_POST['launch_message'] ?? '');
            $scripture = sanitizeInput($_POST['scripture'] ?? '');
            $scriptureText = sanitizeInput($_POST['scripture_text'] ?? '');
            $notifyAtLaunch = isset($_POST['notify_at_launch']) ? true : false;
            $notifyMilestones = isset($_POST['notify_milestones']) ? true : false;
            $notifyReminders = isset($_POST['notify_reminders']) ? true : false;
            $coverImage = $_POST['cover_image'] ?? '';
            $videoUrl = sanitizeInput($_POST['video_url'] ?? '');
            $socialTitle = sanitizeInput($_POST['social_title'] ?? '');
            $socialDesc = sanitizeInput($_POST['social_desc'] ?? '');
            
            if (empty($title)) {
                throw new Exception('Project name is required');
            }
            
            if ($formAction === 'create') {
                $db->execute(
                    "INSERT INTO projects (title, description, category, goal_amount, current_amount, start_date, end_date, is_active, display_order, icon, created_at)
                     VALUES (:title, :description, :category, :goal_amount, 0, :start_date, :end_date, :is_active, :display_order, :icon, NOW())",
                    [
                        'title' => $title,
                        'description' => $description,
                        'category' => $category,
                        'goal_amount' => $goalAmount,
                        'start_date' => $startDate,
                        'end_date' => $endDate,
                        'is_active' => $isActive,
                        'display_order' => $displayOrder,
                        'icon' => $icon,
                    ]
                );
                
                $formProjectId = $db->lastInsertId();
                logAdminAction($admin['admin_id'], 'PROJECT_CREATE', 'project', $formProjectId, $title);
                // Redirect to prevent form resubmission
                header('Location: projects.php?success=created');
                exit;
            } else {
                $db->execute(
                    "UPDATE projects 
                     SET title = :title, description = :description, category = :category,
                         goal_amount = :goal_amount, start_date = :start_date, end_date = :end_date,
                         is_active = :is_active, display_order = :display_order, icon = :icon
                     WHERE project_id = :project_id",
                    [
                        'title' => $title,
                        'description' => $description,
                        'category' => $category,
                        'goal_amount' => $goalAmount,
                        'start_date' => $startDate,
                        'end_date' => $endDate,
                        'is_active' => $isActive,
                        'display_order' => $displayOrder,
                        'icon' => $icon,
                        'project_id' => $formProjectId,
                    ]
                );
                
                logAdminAction($admin['admin_id'], 'PROJECT_UPDATE', 'project', $formProjectId, $title);
                // Redirect to prevent form resubmission
                header('Location: projects.php?success=updated');
                exit;
            }
        } elseif ($formAction === 'delete') {
            $project = $db->fetchOne("SELECT title FROM projects WHERE project_id = :id", ['id' => $formProjectId]);
            if ($project) {
                $db->execute("DELETE FROM projects WHERE project_id = :id", ['id' => $formProjectId]);
                logAdminAction($admin['admin_id'], 'PROJECT_DELETE', 'project', $formProjectId, $project['title']);
                $success = 'Project deleted successfully';
                // Redirect to clear the URL
                header('Location: projects.php?success=deleted');
                exit;
            }
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Get project data
$project = null;
if ($action === 'edit' && $projectId) {
    $project = $db->fetchOne(
        "SELECT * FROM projects WHERE project_id = :id",
        ['id' => $projectId]
    );
} elseif ($action === 'create') {
    // Redirect to modal on create action
    $action = 'list';
}

// Get projects list
$projects = $db->fetchAll(
    "SELECT *, 
            CASE WHEN goal_amount > 0 THEN (current_amount / goal_amount) * 100 ELSE 0 END as progress_percentage
     FROM projects 
     ORDER BY display_order, created_at DESC"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projects - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;0,9..144,700;1,9..144,500&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="form-styles.css" rel="stylesheet">
    <style>
        :root {
            --gold: #C9A24B;
            --gold-light: #E7D9B4;
            --gold-dark: #A8863A;
            --dark: #0F1B2D;
            --deep: #122137;
            --cream: #FAF6EF;
            --cream-light: #F5F0E8;
            --text-primary: #0F1B2D;
            --text-secondary: rgba(15, 27, 45, 0.55);
            --text-muted: rgba(15, 27, 45, 0.4);
            --success: #28a745;
            --warning: #ffc107;
            --danger: #dc3545;
            --info: #17a2b8;
            --radius-sm: 14px;
            --radius-md: 14px;
            --radius-lg: 24px;
            --shadow-sm: 0 2px 4px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 12px rgba(0,0,0,0.1);
            --shadow-lg: 0 8px 24px rgba(0,0,0,0.15);
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Inter', sans-serif; 
            background: #FAF6EF; 
            color: #0F1B2D;
            min-height: 100vh;
        }
        h1, h2, h3, h4 { font-family: 'Fraunces', serif; }
        .font-serif { font-family: 'Fraunces', serif; }
        
        /* Sidebar */
        .sidebar {
            position: fixed; left: 0; top: 0; bottom: 0; width: 280px;
            background: var(--dark); color: white; padding: 24px 0; overflow-y: auto; z-index: 1000;
        }
        .sidebar-header { padding: 0 24px 24px; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar-logo { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
        .sidebar-logo-icon { width: 40px; height: 40px; background: var(--gold); border-radius: var(--radius-sm); display: flex; align-items: center; justify-content: center; font-size: 20px; color: var(--dark); }
        .sidebar-logo-text { font-family: 'Playfair Display', serif; font-size: 14px; }
        .sidebar-logo-text span { display: block; font-size: 10px; font-family: 'Inter', sans-serif; color: rgba(255,255,255,0.6); }
        .admin-info { display: flex; align-items: center; gap: 12px; padding: 16px 24px; background: rgba(255,255,255,0.05); border-radius: var(--radius-md); margin: 16px 12px; }
        .admin-avatar { width: 40px; height: 40px; background: var(--gold); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; color: var(--dark); }
        .admin-details { flex: 1; }
        .admin-name { font-size: 12px; font-weight: 500; }
        .admin-email { font-size: 10px; color: rgba(255,255,255,0.5); }
        .nav-menu { list-style: none; padding: 0 12px; }
        .nav-item { margin: 4px 0; }
        .nav-link { display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: rgba(255,255,255,0.7); text-decoration: none; border-radius: var(--radius-md); transition: all 0.2s; font-size: 14px; }
        .nav-link:hover, .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .nav-link i { width: 20px; text-align: center; }
        .nav-section { padding: 16px 12px 8px; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; color: rgba(255,255,255,0.4); }
        .sidebar-footer { position: absolute; bottom: 0; left: 0; right: 0; padding: 16px 12px; border-top: 1px solid rgba(255,255,255,0.1); }
        .sidebar-footer .nav-link:hover { color: var(--danger); }
        
        .main-content { margin-left: 280px; flex: 1; padding: 32px; }
        
        /* Modal Overlay */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 2000;
            align-items: center;
            justify-content: center;
            overflow-y: auto;
        }
        .modal-overlay.active { display: flex; }
        
        /* Modal */
        .modal {
            background: white;
            border-radius: var(--radius-lg);
            width: 95%;
            max-width: 1100px;
            max-height: 95vh;
            overflow-y: auto;
            box-shadow: var(--shadow-lg);
            margin: 20px;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 24px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }
        
        .modal-title { font-size: 20px; font-weight: 600; color: var(--dark); }
        
        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            color: var(--text-muted);
            cursor: pointer;
            padding: 4px;
        }
        .modal-close:hover { color: var(--text-primary); }
        
        .modal-body { padding: 24px; }
        
        /* Form Styles */
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        .form-group { margin-bottom: 20px; }
        .form-label { display: block; font-size: 13px; font-weight: 500; color: var(--text-secondary); margin-bottom: 8px; }
        .form-input, .form-select, .form-textarea {
            width: 100%;
            padding: 12px 16px;
            border: 1.5px solid rgba(0,0,0,0.1);
            border-radius: var(--radius-sm);
            font-size: 14px;
            font-family: 'Inter', sans-serif;
            transition: all 0.2s;
        }
        .form-input:focus, .form-select:focus, .form-textarea:focus {
            outline: none;
            border-color: var(--gold);
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        }
        .form-textarea { resize: vertical; min-height: 100px; }
        
        /* Icon Picker */
        .icon-picker { display: flex; flex-wrap: wrap; gap: 12px; }
        .icon-option input[type="radio"] { display: none; }
        .icon-option label {
            width: 56px; height: 56px;
            border: 2px solid rgba(0,0,0,0.1);
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        .icon-option input:checked + label {
            border-color: var(--gold);
            background: var(--gold);
            color: var(--dark);
        }
        .icon-option label:hover { border-color: var(--gold); }
        
        /* Color Picker */
        .color-picker { display: flex; gap: 12px; }
        .color-option input[type="radio"] { display: none; }
        .color-option label {
            width: 36px; height: 36px;
            border-radius: 50%;
            cursor: pointer;
            border: 3px solid transparent;
            transition: all 0.2s;
        }
        .color-option input:checked + label {
            border-color: var(--dark);
            transform: scale(1.1);
        }
        
        /* Toggle Switch */
        .toggle-switch { position: relative; width: 48px; height: 26px; }
        .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .toggle-slider {
            position: absolute; inset: 0;
            background: rgba(0,0,0,0.1);
            border-radius: 999px;
            cursor: pointer;
            transition: 0.2s;
        }
        .toggle-slider::before {
            content: '';
            position: absolute;
            height: 20px; width: 20px;
            left: 3px; top: 3px;
            background: white;
            border-radius: 50%;
            transition: 0.2s;
            box-shadow: 0 1px 4px rgba(0,0,0,0.15);
        }
        .toggle-switch input:checked + .toggle-slider { background: var(--gold); }
        .toggle-switch input:checked + .toggle-slider::before { transform: translateX(22px); }
        
        /* Toggle Card */
        .toggle-card {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px;
            background: var(--cream-light);
            border-radius: var(--radius-md);
            border: 1px solid rgba(0,0,0,0.05);
        }
        
        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            border-radius: var(--radius-sm);
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
        }
        .btn-primary { background: var(--gold); color: var(--dark); }
        .btn-primary:hover { background: var(--gold-dark); }
        .btn-secondary { background: white; color: var(--text-primary); border: 1px solid rgba(0,0,0,0.1); }
        .btn-secondary:hover { background: var(--cream-light); }
        .btn-danger { background: var(--danger); color: white; }
        .btn-sm { padding: 8px 16px; font-size: 13px; }
        
        /* Project Cards */
        .project-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 24px; }
        .project-card {
            background: white;
            border-radius: var(--radius-lg);
            border: 1px solid rgba(0,0,0,0.08);
            overflow: hidden;
            transition: all 0.2s;
        }
        .project-card:hover { box-shadow: var(--shadow-md); transform: translateY(-2px); }
        .project-card-header {
            padding: 20px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }
        .project-card-body { padding: 20px; }
        .project-icon {
            width: 48px; height: 48px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: white;
        }
        .project-badge {
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 500;
            text-transform: uppercase;
        }
        .project-title { font-size: 16px; font-weight: 600; margin: 12px 0 8px; }
        .project-description { font-size: 13px; color: var(--text-secondary); margin-bottom: 16px; }
        .project-stats { display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 13px; }
        .project-stat { color: var(--text-secondary); }
        .project-stat strong { color: var(--dark); }
        .progress-bar {
            height: 8px;
            background: rgba(0,0,0,0.05);
            border-radius: 4px;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--gold) 0%, var(--gold-light) 100%);
            border-radius: 4px;
        }
        .project-actions { display: flex; gap: 8px; margin-top: 16px; }
        
        /* Alert */
        .alert { padding: 14px 18px; border-radius: var(--radius-sm); margin-bottom: 20px; }
        .alert-success { background: rgba(40, 167, 69, 0.1); color: var(--success); border: 1px solid rgba(40, 167, 69, 0.3); }
        .alert-error { background: rgba(220, 53, 69, 0.1); color: var(--danger); border: 1px solid rgba(220, 53, 69, 0.3); }
        
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0; }
            .form-row { grid-template-columns: 1fr; }
        }
    
        /* ── Responsive sidebar & hamburger ── */
        .sidebar { transition: transform 0.3s ease; }
        .sidebar.open { transform: translateX(0) !important; }

        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999;
        }
        .sidebar-overlay.active { display: block; }

        .hamburger {
            display: none;
            background: none;
            border: none;
            font-size: 22px;
            color: var(--dark, #0F1B2D);
            cursor: pointer;
            padding: 6px 10px;
            border-radius: 6px;
            line-height: 1;
            flex-shrink: 0;
        }
        .hamburger:hover { background: rgba(0,0,0,0.05); }

        .page-header-left {
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }

        @media (max-width: 1024px) {
            .hamburger { display: flex; align-items: center; justify-content: center; }
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0 !important; }
        }

        @media (max-width: 768px) {
            .main-content { padding: 16px !important; }
            .page-header { flex-wrap: wrap; gap: 12px; margin-bottom: 20px !important; }
            .page-actions { width: 100%; justify-content: flex-end; }
            .page-title h1 { font-size: 22px !important; }
            .metrics-grid { grid-template-columns: repeat(2, 1fr) !important; gap: 12px !important; }
            .filter-grid { grid-template-columns: 1fr !important; }
            .form-row { grid-template-columns: 1fr !important; }
            .metric-value { font-size: 24px !important; }
            .card-header, .card-body { padding: 16px !important; }
            .modal { width: 95% !important; border-radius: 12px !important; }
            .table-container { overflow-x: auto; }
            .btn-label { display: none; }
        }

        @media (max-width: 480px) {
            .metrics-grid { grid-template-columns: 1fr !important; }
            .main-content { padding: 12px !important; }
            .page-title h1 { font-size: 19px !important; }
        }

    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <div class="sidebar-logo-icon">✝</div>
                <div class="sidebar-logo-text">
                    Bright Light Ministry Int'l
                    <span>Admin Dashboard</span>
                </div>
            </div>
            <div class="admin-info">
                <div class="admin-avatar"><?php echo strtoupper(substr($admin['first_name'], 0, 1) . substr($admin['last_name'], 0, 1)); ?></div>
                <div class="admin-details">
                    <div class="admin-name"><?php echo e($admin['first_name'] . ' ' . $admin['last_name']); ?></div>
                    <div class="admin-email"><?php echo e($admin['email']); ?></div>
                </div>
            </div>
        </div>
        <nav>
            <ul class="nav-menu">
                <li class="nav-section">Dashboard</li>
                <li class="nav-item"><a href="index.php" class="nav-link"><i class="fas fa-home"></i><span>Overview</span></a></li>
                <li class="nav-section">Management</li>
                <li class="nav-item"><a href="projects.php" class="nav-link active"><i class="fas fa-project-diagram"></i><span>Projects</span></a></li>
                <li class="nav-item"><a href="users.php" class="nav-link"><i class="fas fa-users"></i><span>Users</span></a></li>
                <li class="nav-item"><a href="transactions.php" class="nav-link"><i class="fas fa-exchange-alt"></i><span>Transactions</span></a></li>
                <li class="nav-item"><a href="plans.php" class="nav-link"><i class="fas fa-tags"></i><span>Payment Plans</span></a></li>
                <li class="nav-item"><a href="partners.php" class="nav-link"><i class="fas fa-handshake"></i><span>Partners</span></a></li>
                <li class="nav-section">Administration</li>
                <li class="nav-item"><a href="admin-members.php" class="nav-link"><i class="fas fa-user-shield"></i><span>Admin Members</span></a></li>
                <li class="nav-item"><a href="audit-logs.php" class="nav-link"><i class="fas fa-history"></i><span>Audit Logs</span></a></li>
                <li class="sidebar-footer">
                    <ul class="nav-menu">
                        <li class="nav-item"><a href="logout.php" class="nav-link"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="main-content">
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo e($success); ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo e($error); ?></div>
        <?php endif; ?>
        
        <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; flex-wrap: wrap; gap: 12px;">
            <div class="page-header-left">
                <button class="hamburger" onclick="toggleSidebar()" aria-label="Toggle menu"><i class="fas fa-bars"></i></button>
                <div>
                    <h1 style="font-size: 28px; color: var(--dark); margin-bottom: 4px;">Projects</h1>
                    <p style="color: var(--text-secondary); font-size: 14px;">Manage fundraising projects and campaigns</p>
                </div>
            </div>
            <button class="btn btn-primary" onclick="openProjectModal(null)">
                <i class="fas fa-plus"></i><span class="btn-label"> New Project</span>
            </button>
        </div>
        
        <div class="project-grid">
            <?php foreach ($projects as $p): 
                $progress = min($p['progress_percentage'], 100);
                $iconColors = ['building' => '#1a1a2e', 'globe' => '#D4AF37', 'star' => '#D4AF37', 'book' => '#5B7B6A', 'heart' => '#dc3545', 'cross' => '#1a1a2e', 'people' => '#17a2b8', 'leaf' => '#28a745'];
            ?>
                <div class="project-card">
                    <div class="project-card-header">
                        <div style="display: flex; justify-content: space-between; align-items: start;">
                            <div class="project-icon" style="background: <?php echo $iconColors[$p['icon']] ?? '#1a1a2e'; ?>">
                                <i class="fas fa-<?php echo e($p['icon'] ?? 'building'); ?>"></i>
                            </div>
                            <span class="project-badge" style="background: rgba(212, 175, 55, 0.1); color: var(--gold-dark);"><?php echo e($p['category'] ?? 'General'); ?></span>
                        </div>
                        <h3 class="project-title"><?php echo e($p['title']); ?></h3>
                        <p class="project-description"><?php echo e(substr($p['short_description'] ?? $p['description'], 0, 100)); ?><?php echo strlen($p['short_description'] ?? $p['description']) > 100 ? '...' : ''; ?></p>
                    </div>
                    <div class="project-card-body">
                        <div class="project-stats">
                            <span class="project-stat"><strong>$<?php echo number_format($p['current_amount'], 2); ?></strong> raised</span>
                            <span class="project-stat"><?php echo number_format($p['partner_count'] ?? 0); ?> partners</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: <?php echo $progress; ?>%"></div>
                        </div>
                        <div style="text-align: right; font-size: 12px; color: var(--text-muted); margin-top: 8px;">
                            <?php echo number_format($progress, 1); ?>% of $<?php echo number_format($p['goal_amount'], 2); ?>
                        </div>
        <div class="project-actions">
                            <button class="btn btn-secondary btn-sm" onclick="openProjectModal(<?php echo (int)$p['project_id']; ?>)">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="deleteProject(<?php echo (int)$p['project_id']; ?>, '<?php echo addslashes($p['title']); ?>')">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </main>
    
    <!-- Create/Edit Project Modal -->
    <div class="modal-overlay" id="projectModal">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title" id="modalTitle">New Project</h3>
                <button class="modal-close" onclick="closeProjectModal()">&times;</button>
            </div>
            <form method="POST" id="projectForm" action="projects.php">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                <input type="hidden" name="action" id="formAction" value="create">
                <input type="hidden" name="id" id="formId" value="">
                
                <div class="modal-body" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 24px;">
                    <!-- Left Column -->
                    <div>
                        <h4 style="font-size: 14px; font-weight: 600; color: var(--text-secondary); margin-bottom: 16px; text-transform: uppercase; letter-spacing: 0.5px;">Basic Information</h4>
                        
                        <div class="form-group">
                            <label class="form-label">Project Name <span style="color: var(--danger);">*</span></label>
                            <input type="text" class="form-input" id="title" name="title" required placeholder="e.g. Building Expansion">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">URL Slug</label>
                            <div style="display: flex; border: 1.5px solid rgba(0,0,0,0.1); border-radius: var(--radius-sm); overflow: hidden;">
                                <span style="padding: 12px 16px; background: rgba(0,0,0,0.03); color: var(--text-muted); font-size: 13px;">church.org/give/</span>
                                <input type="text" class="form-input" id="slug" name="slug" placeholder="building-expansion" style="border: none; border-radius: 0;">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Category <span style="color: var(--danger);">*</span></label>
                                <select class="form-select" id="category" name="category" required>
                                    <option value="">Select category</option>
                                    <option value="building">Building Fund</option>
                                    <option value="missions">Missions</option>
                                    <option value="outreach">Community Outreach</option>
                                    <option value="scholarship">Scholarship</option>
                                    <option value="seasonal">Seasonal</option>
                                    <option value="tithe">Tithe</option>
                                    <option value="offering">General Offering</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Project Type <span style="color: var(--danger);">*</span></label>
                                <select class="form-select" id="project_type" name="project_type" required>
                                    <option value="">Select type</option>
                                    <option value="one-time">One-time drive</option>
                                    <option value="ongoing">Ongoing fund</option>
                                    <option value="pledge">Pledge campaign</option>
                                    <option value="matching">Matching gift</option>
                                    <option value="emergency">Emergency appeal</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Short Description</label>
                            <input type="text" class="form-input" id="short_description" name="short_description" placeholder="One sentence vision statement">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Full Description</label>
                            <textarea class="form-textarea" id="description" name="description" rows="4" placeholder="Tell the full story..."></textarea>
                        </div>
                        
                        <h4 style="font-size: 14px; font-weight: 600; color: var(--text-secondary); margin: 24px 0 16px; text-transform: uppercase; letter-spacing: 0.5px;">Appearance</h4>
                        
                        <div class="form-group">
                            <label class="form-label">Icon</label>
                            <div class="icon-picker">
                                <?php $icons = ['building', 'globe', 'star', 'book', 'heart', 'cross', 'people', 'leaf', 'church']; ?>
                                <?php foreach ($icons as $icon): ?>
                                    <label class="icon-option">
                                        <input type="radio" name="icon" value="<?php echo e($icon); ?>" <?php echo $icon === 'building' ? 'checked' : ''; ?>>
                                        <label>
                                            <i class="fas fa-<?php echo e($icon); ?>"></i>
                                        </label>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Accent Color</label>
                            <div class="color-picker">
                                <label class="color-option">
                                    <input type="radio" name="accent_color" value="dark" checked>
                                    <label style="background: #1a1a2e;"></label>
                                </label>
                                <label class="color-option">
                                    <input type="radio" name="accent_color" value="gold">
                                    <label style="background: #D4AF37;"></label>
                                </label>
                                <label class="color-option">
                                    <input type="radio" name="accent_color" value="sage">
                                    <label style="background: #5B7B6A;"></label>
                                </label>
                                <label class="color-option">
                                    <input type="radio" name="accent_color" value="rose">
                                    <label style="background: #dc3545;"></label>
                                </label>
                                <label class="color-option">
                                    <input type="radio" name="accent_color" value="info">
                                    <label style="background: #17a2b8;"></label>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Right Column -->
                    <div>
                        <h4 style="font-size: 14px; font-weight: 600; color: var(--text-secondary); margin-bottom: 16px; text-transform: uppercase; letter-spacing: 0.5px;">Financial Goals</h4>
                        
                        <div class="form-group">
                            <label class="form-label">Fundraising Goal ($) <span style="color: var(--danger);">*</span></label>
                            <input type="number" class="form-input" id="goal_amount" name="goal_amount" min="1000" step="500" required placeholder="500000">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Starting Amount Raised ($)</label>
                            <input type="number" class="form-input" id="starting_amount" name="starting_amount" min="0" step="100" placeholder="0">
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Start Date</label>
                                <input type="date" class="form-input" id="start_date" name="start_date">
                            </div>
                            <div class="form-group">
                                <label class="form-label">End Date</label>
                                <input type="date" class="form-input" id="end_date" name="end_date">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Minimum Gift ($)</label>
                                <input type="number" class="form-input" id="min_gift" name="min_gift" min="1" placeholder="10">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Maximum Gift ($)</label>
                                <input type="number" class="form-input" id="max_gift" name="max_gift" min="1" placeholder="No limit">
                            </div>
                        </div>
                        
                        <h4 style="font-size: 14px; font-weight: 600; color: var(--text-secondary); margin: 24px 0 16px; text-transform: uppercase; letter-spacing: 0.5px;">Settings</h4>
                        
                        <div class="toggle-card">
                            <div>
                                <p class="form-label" style="margin-bottom: 4px; font-weight: 500;">Tax-deductible</p>
                                <p style="font-size: 12px; color: var(--text-muted);">Issue 501(c)(3) receipts</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="is_tax_deductible" checked>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        
                        <div class="toggle-card" style="margin-top: 12px;">
                            <div>
                                <p class="form-label" style="margin-bottom: 4px; font-weight: 500;">Matching gift enabled</p>
                                <p style="font-size: 12px; color: var(--text-muted);">Double donor impact</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="is_matching_enabled" id="matching_enabled" onchange="toggleMatching()">
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        
                        <div id="matching_details" style="display: none; margin-top: 12px; padding: 16px; background: var(--cream-light); border-radius: var(--radius-md);">
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Match Ratio</label>
                                    <select class="form-select" name="match_ratio">
                                        <option value="1:1">1:1 (Dollar for dollar)</option>
                                        <option value="2:1">2:1 (Double match)</option>
                                        <option value="0.5:1">0.5:1 (50¢ per dollar)</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Match Cap ($)</label>
                                    <input type="number" class="form-input" name="match_cap" placeholder="50000">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Sponsor Name</label>
                                <input type="text" class="form-input" name="match_sponsor" placeholder="e.g. The Johnson Family">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Project Manager</label>
                            <select class="form-select" name="project_manager">
                                <option value="">Select manager</option>
                                <option value="pastor">Pastor Nathaniel Williams</option>
                                <option value="admin">Admin — Bright Light Ministry</option>
                                <option value="finance">Finance Team</option>
                                <option value="missions">Missions Department</option>
                            </select>
                        </div>
                        
                        <h4 style="font-size: 14px; font-weight: 600; color: var(--text-secondary); margin: 24px 0 16px; text-transform: uppercase; letter-spacing: 0.5px;">Visibility</h4>
                        
                        <div class="form-group">
                            <label class="form-label">Visibility</label>
                            <select class="form-select" name="visibility" id="visibility">
                                <option value="public">Public — visible to all members</option>
                                <option value="members">Members only</option>
                                <option value="invite">Invite only</option>
                                <option value="draft">Draft — not yet visible</option>
                            </select>
                        </div>
                        
                        <div class="toggle-card">
                            <div>
                                <p class="form-label" style="margin-bottom: 4px; font-weight: 500;">Feature on homepage</p>
                                <p style="font-size: 12px; color: var(--text-muted);">Show in spotlight carousel</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="is_featured">
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        
                        <div class="toggle-card" style="margin-top: 12px;">
                            <div>
                                <p class="form-label" style="margin-bottom: 4px; font-weight: 500;">Allow anonymous giving</p>
                                <p style="font-size: 12px; color: var(--text-muted);">Hide donor names if chosen</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="allow_anonymous" checked>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        
                        <div class="toggle-card" style="margin-top: 12px;">
                            <div>
                                <p class="form-label" style="margin-bottom: 4px; font-weight: 500;">Project is active</p>
                                <p style="font-size: 12px; color: var(--text-muted);">Accept donations immediately</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="is_active" checked>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                    </div>
                    
                    <!-- Additional Settings Column -->
                    <div>
                        <h4 style="font-size: 14px; font-weight: 600; color: var(--text-secondary); margin-bottom: 16px; text-transform: uppercase; letter-spacing: 0.5px;">Additional Settings</h4>
                        
                        <div class="form-group">
                            <label class="form-label">Launch Message</label>
                            <textarea class="form-textarea" name="launch_message" rows="3" placeholder="Message to send when project launches..."></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Scripture Reference</label>
                            <input type="text" class="form-input" name="scripture" placeholder="e.g. Mark 11:24">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Scripture Text</label>
                            <textarea class="form-textarea" name="scripture_text" rows="2" placeholder="Full scripture text..."></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Cover Image URL</label>
                            <input type="text" class="form-input" name="cover_image" placeholder="https://example.com/image.jpg">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Video URL</label>
                            <input type="text" class="form-input" name="video_url" placeholder="https://youtube.com/watch?v=...">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Social Media Title</label>
                            <input type="text" class="form-input" name="social_title" placeholder="Title for social sharing">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Social Media Description</label>
                            <textarea class="form-textarea" name="social_desc" rows="2" placeholder="Description for social sharing"></textarea>
                        </div>
                        
                        <h4 style="font-size: 14px; font-weight: 600; color: var(--text-secondary); margin: 24px 0 16px; text-transform: uppercase; letter-spacing: 0.5px;">Notifications</h4>
                        
                        <div class="toggle-card">
                            <div>
                                <p class="form-label" style="margin-bottom: 4px; font-weight: 500;">Notify at launch</p>
                                <p style="font-size: 12px; color: var(--text-muted);">Email partners when project launches</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="notify_at_launch">
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        
                        <div class="toggle-card" style="margin-top: 12px;">
                            <div>
                                <p class="form-label" style="margin-bottom: 4px; font-weight: 500;">Notify milestones</p>
                                <p style="font-size: 12px; color: var(--text-muted);">Email partners at funding milestones</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="notify_milestones">
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        
                        <div class="toggle-card" style="margin-top: 12px;">
                            <div>
                                <p class="form-label" style="margin-bottom: 4px; font-weight: 500;">Send reminders</p>
                                <p style="font-size: 12px; color: var(--text-muted);">Send periodic donation reminders</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="notify_reminders">
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                    </div>
                </div>
                
                <div style="padding: 24px; border-top: 1px solid rgba(0,0,0,0.05); display: flex; gap: 12px; justify-content: flex-end;">
                    <button type="button" class="btn btn-secondary" onclick="closeProjectModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-check"></i> Save Project
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // Project data cache - store all projects
        let projectDataCache = <?php 
            $cacheData = array_map(function($p) {
                return [
                    'project_id' => (int)($p['project_id'] ?? 0),
                    'title' => $p['title'] ?? '',
                    'description' => $p['description'] ?? '',
                    'category' => $p['category'] ?? '',
                    'goal_amount' => floatval($p['goal_amount'] ?? 0),
                    'current_amount' => floatval($p['current_amount'] ?? 0),
                    'start_date' => $p['start_date'] ?? '',
                    'end_date' => $p['end_date'] ?? '',
                    'is_active' => !empty($p['is_active']) ? true : false,
                    'display_order' => (int)($p['display_order'] ?? 0),
                    'icon' => $p['icon'] ?? 'building',
                ];
            }, $projects);
            echo json_encode($cacheData); 
        ?>;
        
        function openProjectModal(projectId = null) {
            const modal = document.getElementById('projectModal');
            const formAction = document.getElementById('formAction');
            const formId = document.getElementById('formId');
            const modalTitle = document.getElementById('modalTitle');
            
            // Get all form elements at the start
            const titleEl = document.getElementById('title');
            const slugEl = document.getElementById('slug');
            const categoryEl = document.getElementById('category');
            const projectTypeEl = document.getElementById('project_type');
            const shortDescEl = document.getElementById('short_description');
            const descEl = document.getElementById('description');
            const goalAmountEl = document.getElementById('goal_amount');
            const startingAmountEl = document.getElementById('starting_amount');
            const startDateEl = document.getElementById('start_date');
            const endDateEl = document.getElementById('end_date');
            const minGiftEl = document.getElementById('min_gift');
            const maxGiftEl = document.getElementById('max_gift');
            const projectManagerEl = document.getElementById('project_manager');
            const visibilityEl = document.getElementById('visibility');
            const projectForm = document.getElementById('projectForm');
            
            // Find project data in cache
            const projectData = projectDataCache.find(p => p.project_id == projectId);
            
            if (projectId && projectData) {
                // Edit mode with pre-filled data
                if (formAction) formAction.value = 'edit';
                if (formId) formId.value = projectId;
                if (modalTitle) modalTitle.textContent = 'Edit Project';
                
                // Pre-fill form fields with null checks
                if (titleEl) titleEl.value = projectData.title || '';
                if (slugEl) slugEl.value = '';
                if (categoryEl) categoryEl.value = projectData.category || '';
                if (projectTypeEl) projectTypeEl.value = 'one-time';
                if (shortDescEl) shortDescEl.value = '';
                if (descEl) descEl.value = projectData.description || '';
                if (goalAmountEl) goalAmountEl.value = projectData.goal_amount || '';
                if (startingAmountEl) startingAmountEl.value = '';
                if (startDateEl) startDateEl.value = projectData.start_date || '';
                if (endDateEl) endDateEl.value = projectData.end_date || '';
                if (minGiftEl) minGiftEl.value = '';
                if (maxGiftEl) maxGiftEl.value = '';
                if (projectManagerEl) projectManagerEl.value = '';
                if (visibilityEl) visibilityEl.value = 'public';
                
                // Set icon
                const iconRadios = document.getElementsByName('icon');
                iconRadios.forEach(radio => {
                    if (radio.value === (projectData.icon || 'building')) {
                        radio.checked = true;
                    }
                });
                
                // Set toggles to defaults
                const taxDeductibleEl = document.querySelector('input[name="is_tax_deductible"]');
                const featuredEl = document.querySelector('input[name="is_featured"]');
                const anonymousEl = document.querySelector('input[name="allow_anonymous"]');
                if (taxDeductibleEl) taxDeductibleEl.checked = true;
                if (featuredEl) featuredEl.checked = false;
                if (anonymousEl) anonymousEl.checked = true;
                
                // Set matching gift to defaults
                const matchingEnabledEl = document.getElementById('matching_enabled');
                if (matchingEnabledEl) matchingEnabledEl.checked = false;
                toggleMatching();
                
                // Set additional settings to defaults
                const launchMessageEl = document.querySelector('textarea[name="launch_message"]');
                const scriptureEl = document.querySelector('input[name="scripture"]');
                const scriptureTextEl = document.querySelector('textarea[name="scripture_text"]');
                const coverImageEl = document.querySelector('input[name="cover_image"]');
                const videoUrlEl = document.querySelector('input[name="video_url"]');
                const socialTitleEl = document.querySelector('input[name="social_title"]');
                const socialDescEl = document.querySelector('textarea[name="social_desc"]');
                if (launchMessageEl) launchMessageEl.value = '';
                if (scriptureEl) scriptureEl.value = '';
                if (scriptureTextEl) scriptureTextEl.value = '';
                if (coverImageEl) coverImageEl.value = '';
                if (videoUrlEl) videoUrlEl.value = '';
                if (socialTitleEl) socialTitleEl.value = '';
                if (socialDescEl) socialDescEl.value = '';
                
                // Set notification toggles to defaults
                const notifyAtLaunchEl = document.querySelector('input[name="notify_at_launch"]');
                const notifyMilestonesEl = document.querySelector('input[name="notify_milestones"]');
                const notifyRemindersEl = document.querySelector('input[name="notify_reminders"]');
                if (notifyAtLaunchEl) notifyAtLaunchEl.checked = false;
                if (notifyMilestonesEl) notifyMilestonesEl.checked = false;
                if (notifyRemindersEl) notifyRemindersEl.checked = false;
                
            } else {
                // Create mode
                if (formAction) formAction.value = 'create';
                if (formId) formId.value = '';
                if (modalTitle) modalTitle.textContent = 'New Project';
                if (projectForm) projectForm.reset();
                
                // Reset to default icon
                const defaultIcon = document.querySelector('input[name="icon"][value="building"]');
                if (defaultIcon) defaultIcon.checked = true;
                
                // Reset additional settings
                const launchMessageEl = document.querySelector('textarea[name="launch_message"]');
                const scriptureEl = document.querySelector('input[name="scripture"]');
                const scriptureTextEl = document.querySelector('textarea[name="scripture_text"]');
                const coverImageEl = document.querySelector('input[name="cover_image"]');
                const videoUrlEl = document.querySelector('input[name="video_url"]');
                const socialTitleEl = document.querySelector('input[name="social_title"]');
                const socialDescEl = document.querySelector('textarea[name="social_desc"]');
                if (launchMessageEl) launchMessageEl.value = '';
                if (scriptureEl) scriptureEl.value = '';
                if (scriptureTextEl) scriptureTextEl.value = '';
                if (coverImageEl) coverImageEl.value = '';
                if (videoUrlEl) videoUrlEl.value = '';
                if (socialTitleEl) socialTitleEl.value = '';
                if (socialDescEl) socialDescEl.value = '';
                
                // Reset notification toggles
                const notifyAtLaunchEl = document.querySelector('input[name="notify_at_launch"]');
                const notifyMilestonesEl = document.querySelector('input[name="notify_milestones"]');
                const notifyRemindersEl = document.querySelector('input[name="notify_reminders"]');
                if (notifyAtLaunchEl) notifyAtLaunchEl.checked = false;
                if (notifyMilestonesEl) notifyMilestonesEl.checked = false;
                if (notifyRemindersEl) notifyRemindersEl.checked = false;
            }
            
            if (modal) modal.classList.add('active');
        }
        
        function closeProjectModal() {
            document.getElementById('projectModal').classList.remove('active');
        }
        
        function toggleMatching() {
            const show = document.getElementById('matching_enabled').checked;
            document.getElementById('matching_details').style.display = show ? 'block' : 'none';
        }
        
        // Auto-slug
        document.getElementById('title')?.addEventListener('input', function() {
            const slug = this.value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
            document.getElementById('slug').value = slug;
        });
        
        // Close modal on overlay click
        document.getElementById('projectModal')?.addEventListener('click', function(e) {
            if (e.target === this) closeProjectModal();
        });
        
        // Delete project function
        function deleteProject(projectId, projectName) {
            if (confirm('Are you sure you want to delete "' + projectName + '"? This action cannot be undone.')) {
                // Create a hidden form to submit the delete request with CSRF token
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'projects.php';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'delete';
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'id';
                idInput.value = projectId;
                
                const csrfInput = document.createElement('input');
                csrfInput.type = 'hidden';
                csrfInput.name = 'csrf_token';
                csrfInput.value = '<?php echo generateCSRFToken(); ?>';
                
                form.appendChild(actionInput);
                form.appendChild(idInput);
                form.appendChild(csrfInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>

    <!-- Responsive sidebar JS -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>
    <script>
        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('open');
            document.getElementById('sidebarOverlay').classList.toggle('active');
        }
        function closeSidebar() {
            document.querySelector('.sidebar').classList.remove('open');
            document.getElementById('sidebarOverlay').classList.remove('active');
        }
        document.querySelectorAll('.nav-link').forEach(function(link) {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 1024) closeSidebar();
            });
        });
    </script>

</body>
</html>