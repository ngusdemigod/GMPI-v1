<?php
/**
 * User Management Page
 * Church Financial Partnership System
 */

require_once __DIR__ . '/includes/config.php';

// Require authentication
$admin = requireAdmin();

$db = Database::getInstance();
$action = $_SERVER['REQUEST_METHOD'] === 'POST' ? ($_POST['action'] ?? '') : ($_GET['action'] ?? 'list');
$userId = $_POST['id'] ?? ($_GET['id'] ?? null);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    try {
        if ($action === 'edit_profile') {
            $firstName = sanitizeInput($_POST['first_name'] ?? '');
            $lastName = sanitizeInput($_POST['last_name'] ?? '');
            $phone = sanitizeInput($_POST['phone'] ?? '');
            $addressLine1 = sanitizeInput($_POST['address_line1'] ?? '');
            $addressLine2 = sanitizeInput($_POST['address_line2'] ?? '');
            $city = sanitizeInput($_POST['city'] ?? '');
            $state = sanitizeInput($_POST['state'] ?? '');
            $postalCode = sanitizeInput($_POST['postal_code'] ?? '');
            
            $db->execute(
                "UPDATE users SET 
                 first_name = :first_name, last_name = :last_name, phone = :phone,
                 address_line1 = :address_line1, address_line2 = :address_line2,
                 city = :city, state = :state, postal_code = :postal_code
                 WHERE user_id = :user_id",
                [
                    'first_name' => $firstName,
                    'last_name' => $lastName,
                    'phone' => $phone,
                    'address_line1' => $addressLine1,
                    'address_line2' => $addressLine2,
                    'city' => $city,
                    'state' => $state,
                    'postal_code' => $postalCode,
                    'user_id' => $userId
                ]
            );
            
            logAdminAction($admin['admin_id'], 'USER_PROFILE_UPDATE', 'user', $userId, "Updated profile for user ID: $userId");
            // Redirect to prevent form resubmission
            header('Location: users.php?action=view&id=' . $userId . '&success=profile_updated');
            exit;
        } elseif ($action === 'toggle_status') {
            $isActive = $_POST['is_active'] === '1';
            $db->execute(
                "UPDATE users SET is_active = :is_active WHERE user_id = :user_id",
                ['is_active' => $isActive, 'user_id' => $userId]
            );
            
            logAdminAction($admin['admin_id'], 'USER_STATUS_CHANGE', 'user', $userId, "Set is_active to: " . ($isActive ? 'true' : 'false'));
            // Redirect to prevent form resubmission
            header('Location: users.php?action=view&id=' . $userId . '&success=status_updated');
            exit;
        } elseif ($action === 'reset_password') {
            $newPassword = $_POST['new_password'] ?? '';
            if (strlen($newPassword) < 8) {
                throw new Exception('Password must be at least 8 characters');
            }
            
            $passwordHash = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12]);
            $db->execute(
                "UPDATE users SET password_hash = :password_hash WHERE user_id = :user_id",
                ['password_hash' => $passwordHash, 'user_id' => $userId]
            );
            
            logAdminAction($admin['admin_id'], 'USER_PASSWORD_RESET', 'user', $userId, 'Password reset by admin');
            // Redirect to prevent form resubmission
            header('Location: users.php?action=view&id=' . $userId . '&success=password_reset');
            exit;
        } elseif ($action === 'delete') {
            $user = $db->fetchOne("SELECT first_name, last_name FROM users WHERE user_id = :id", ['id' => $userId]);
            if ($user) {
                $db->execute("DELETE FROM users WHERE user_id = :id", ['id' => $userId]);
                logAdminAction($admin['admin_id'], 'USER_DELETE', 'user', $userId, "$user->first_name $user->last_name");
                // Redirect to prevent form resubmission
                header('Location: users.php?success=deleted');
                exit;
            }
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Get user data
$user = null;
$userTransactions = [];
$userPledges = [];
$userProjects = [];
if ($action === 'view' && $userId) {
    $user = $db->fetchOne(
        "SELECT * FROM users WHERE user_id = :id",
        ['id' => $userId]
    );
    
    if ($user) {
        $userTransactions = $db->fetchAll(
            "SELECT t.*, p.title as project_title
             FROM transactions t
             LEFT JOIN projects p ON t.project_id = p.project_id
             WHERE t.user_id = :user_id
             ORDER BY t.transaction_date DESC
             LIMIT 20",
            ['user_id' => $userId]
        );
        
        $userPledges = $db->fetchAll(
            "SELECT p.*, pr.title as project_title
             FROM pledges p
             LEFT JOIN projects pr ON p.project_id = pr.project_id
             WHERE p.user_id = :user_id AND p.is_active = TRUE
             ORDER BY p.created_at DESC",
            ['user_id' => $userId]
        );
        
        // Note: project_participants table may not exist, using empty array
        $userProjects = [];
    }
}

// Get users list with aggregated data
$users = $db->fetchAll(
    "SELECT u.*, 
            (SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE user_id = u.user_id AND status = 'completed') as total_given,
            (SELECT COUNT(*) FROM transactions WHERE user_id = u.user_id AND status = 'completed') as transaction_count,
            (SELECT COUNT(*) FROM pledges WHERE user_id = u.user_id AND is_active = TRUE) as active_pledges
     FROM users u
     WHERE u.is_active = TRUE
     ORDER BY u.created_at DESC"
);

// Get total stats
$totalUsers = count($users);
$totalGiven = array_sum(array_column($users, 'total_given'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Admin Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;0,9..144,700;1,9..144,500&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="form-styles.css" rel="stylesheet">
    <style>
        :root {
            --gold: #C9A24B;
            --gold-light: #E7D9B4;
            --gold-dark: #A8863A;
            --dark: #0F1B2D;
            --deep: #122137;
            --cream: #FAF6EF;
            --cream-light: #F5F0E8;
            --text-primary: #0F1B2D;
            --text-secondary: rgba(15, 27, 45, 0.55);
            --text-muted: rgba(15, 27, 45, 0.4);
            --success: #28a745;
            --warning: #ffc107;
            --danger: #dc3545;
            --info: #17a2b8;
            --radius-sm: 14px;
            --radius-md: 14px;
            --radius-lg: 24px;
            --shadow-sm: 0 2px 4px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 12px rgba(0,0,0,0.1);
            --shadow-lg: 0 8px 24px rgba(0,0,0,0.15);
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Inter', sans-serif; 
            background: #FAF6EF; 
            color: #0F1B2D;
            min-height: 100vh;
        }
        h1, h2, h3, h4 { font-family: 'Fraunces', serif; }
        .font-serif { font-family: 'Fraunces', serif; }
        
        .layout { display: flex; min-height: 100vh; }
        
        .sidebar {
            position: fixed; left: 0; top: 0; bottom: 0; width: 280px;
            background: var(--dark); color: white; padding: 24px 0; overflow-y: auto; z-index: 1000;
        }
        .sidebar-header { padding: 0 24px 24px; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar-logo { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
        .sidebar-logo-icon { width: 40px; height: 40px; background: var(--gold); border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 20px; color: var(--dark); }
        .sidebar-logo-text { font-family: 'Playfair Display', serif; font-size: 14px; }
        .sidebar-logo-text span { display: block; font-size: 10px; font-family: 'Inter', sans-serif; color: rgba(255,255,255,0.6); }
        .admin-info { display: flex; align-items: center; gap: 12px; padding: 16px 24px; background: rgba(255,255,255,0.05); border-radius: 12px; margin: 16px 12px; }
        .admin-avatar { width: 40px; height: 40px; background: var(--gold); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; color: var(--dark); }
        .admin-details { flex: 1; }
        .admin-name { font-size: 12px; font-weight: 500; }
        .admin-email { font-size: 10px; color: rgba(255,255,255,0.5); }
        .nav-menu { list-style: none; padding: 0 12px; }
        .nav-item { margin: 4px 0; }
        .nav-link { display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: rgba(255,255,255,0.7); text-decoration: none; border-radius: 12px; transition: all 0.2s; font-size: 14px; }
        .nav-link:hover, .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .nav-link i { width: 20px; text-align: center; }
        .nav-section { padding: 16px 12px 8px; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; color: rgba(255,255,255,0.4); }
        .sidebar-footer { position: absolute; bottom: 0; left: 0; right: 0; padding: 16px 12px; border-top: 1px solid rgba(255,255,255,0.1); }
        .sidebar-footer .nav-link:hover { color: var(--danger); }
        
        .main-content { margin-left: 280px; flex: 1; padding: 32px; }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; }
        .page-title h1 { font-size: 28px; color: var(--dark); margin-bottom: 4px; }
        .page-title p { color: var(--text-secondary); font-size: 14px; }
        .page-actions { display: flex; gap: 12px; }
        
        .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border-radius: 6px; font-size: 14px; font-weight: 500; text-decoration: none; cursor: pointer; border: none; transition: all 0.2s; }
        .btn-primary { background: var(--gold); color: var(--dark); }
        .btn-primary:hover { background: var(--gold-dark); }
        .btn-secondary { background: white; color: var(--text-primary); border: 1px solid rgba(0,0,0,0.1); }
        .btn-secondary:hover { background: var(--cream-light); }
        .btn-danger { background: var(--danger); color: white; }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        .btn-icon { padding: 8px; }
        
        .card { background: white; border-radius: 16px; box-shadow: var(--shadow-sm); overflow: hidden; }
        .card-header { display: flex; justify-content: space-between; align-items: center; padding: 20px 24px; border-bottom: 1px solid rgba(0,0,0,0.05); }
        .card-title { font-size: 18px; color: var(--dark); }
        .card-body { padding: 24px; }
        
        .metrics-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px; margin-bottom: 32px; }
        .metric-card { background: white; border-radius: 16px; padding: 24px; box-shadow: var(--shadow-sm); }
        .metric-title { font-size: 13px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }
        .metric-value { font-size: 32px; font-weight: 700; color: var(--dark); }
        
        .table-container { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 16px; text-align: left; border-bottom: 1px solid rgba(0,0,0,0.05); }
        th { font-size: 12px; text-transform: uppercase; letter-spacing: 1px; color: var(--text-secondary); font-weight: 500; }
        tr:hover { background: var(--cream-light); cursor: pointer; }
        
        .status-badge { padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 500; }
        .status-active { background: rgba(40, 167, 69, 0.1); color: var(--success); }
        .status-inactive { background: rgba(108, 117, 125, 0.1); color: var(--text-muted); }
        
        .user-avatar { width: 40px; height: 40px; background: var(--gold); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; color: var(--dark); font-size: 14px; }
        
        .form-group { margin-bottom: 20px; }
        .form-label { display: block; font-size: 14px; font-weight: 500; color: var(--text-primary); margin-bottom: 8px; }
        .form-input, .form-select { width: 100%; padding: 12px 16px; border: 1px solid rgba(0,0,0,0.1); border-radius: 6px; font-size: 14px; }
        .form-input:focus, .form-select:focus { outline: none; border-color: var(--gold); box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1); }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        
        .alert { padding: 14px 18px; border-radius: 6px; margin-bottom: 20px; }
        .alert-success { background: rgba(40, 167, 69, 0.1); color: var(--success); border: 1px solid rgba(40, 167, 69, 0.3); }
        .alert-error { background: rgba(220, 53, 69, 0.1); color: var(--danger); border: 1px solid rgba(220, 53, 69, 0.3); }
        
        .section { margin-top: 32px; padding-top: 32px; border-top: 1px solid rgba(0,0,0,0.1); }
        .section-title { font-size: 16px; font-weight: 600; margin-bottom: 16px; color: var(--dark); }
        
        .transaction-item { display: flex; justify-content: space-between; align-items: center; padding: 12px; background: var(--cream-light); border-radius: 8px; margin-bottom: 8px; }
        .transaction-amount { font-weight: 600; color: var(--success); }
        
        .pledge-item { display: flex; justify-content: space-between; align-items: center; padding: 12px; background: var(--cream-light); border-radius: 8px; margin-bottom: 8px; }
        
        .project-item { display: flex; justify-content: space-between; align-items: center; padding: 12px; background: var(--cream-light); border-radius: 8px; margin-bottom: 8px; }
        
        .receipt-btn {
            background: var(--gold);
            color: var(--dark);
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
        }
        .receipt-btn:hover {
            background: var(--gold-dark);
        }
        
        /* Modal Styles */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }
        
        .modal-overlay.active {
            display: flex;
        }
        
        .modal {
            background: white;
            border-radius: 16px;
            width: 90%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: var(--shadow-lg);
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 24px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }
        
        .modal-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--dark);
        }
        
        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            color: var(--text-muted);
            cursor: pointer;
            padding: 4px;
        }
        
        .modal-close:hover {
            color: var(--text-primary);
        }
        
        .modal-body {
            padding: 24px;
        }
        
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0; }
        }
        @media (max-width: 768px) {
            .form-row { grid-template-columns: 1fr; }
            .metrics-grid { grid-template-columns: repeat(2, 1fr); }
        }
    
        /* ── Responsive sidebar & hamburger ── */
        .sidebar { transition: transform 0.3s ease; }
        .sidebar.open { transform: translateX(0) !important; }

        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999;
        }
        .sidebar-overlay.active { display: block; }

        .hamburger {
            display: none;
            background: none;
            border: none;
            font-size: 22px;
            color: var(--dark, #0F1B2D);
            cursor: pointer;
            padding: 6px 10px;
            border-radius: 6px;
            line-height: 1;
            flex-shrink: 0;
        }
        .hamburger:hover { background: rgba(0,0,0,0.05); }

        .page-header-left {
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }

        @media (max-width: 1024px) {
            .hamburger { display: flex; align-items: center; justify-content: center; }
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0 !important; }
        }

        @media (max-width: 768px) {
            .main-content { padding: 16px !important; }
            .page-header { flex-wrap: wrap; gap: 12px; margin-bottom: 20px !important; }
            .page-actions { width: 100%; justify-content: flex-end; }
            .page-title h1 { font-size: 22px !important; }
            .metrics-grid { grid-template-columns: repeat(2, 1fr) !important; gap: 12px !important; }
            .filter-grid { grid-template-columns: 1fr !important; }
            .form-row { grid-template-columns: 1fr !important; }
            .metric-value { font-size: 24px !important; }
            .card-header, .card-body { padding: 16px !important; }
            .modal { width: 95% !important; border-radius: 12px !important; }
            .table-container { overflow-x: auto; }
            .btn-label { display: none; }
        }

        @media (max-width: 480px) {
            .metrics-grid { grid-template-columns: 1fr !important; }
            .main-content { padding: 12px !important; }
            .page-title h1 { font-size: 19px !important; }
        }

    </style>
</head>
<body>
    <div class="layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <div class="sidebar-logo-icon">✝</div>
                    <div class="sidebar-logo-text">
                        Bright Light Ministry Int'l
                        <span>Admin Dashboard</span>
                    </div>
                </div>
                <div class="admin-info">
                    <div class="admin-avatar"><?php echo strtoupper(substr($admin['first_name'], 0, 1) . substr($admin['last_name'], 0, 1)); ?></div>
                    <div class="admin-details">
                        <div class="admin-name"><?php echo e($admin['first_name'] . ' ' . $admin['last_name']); ?></div>
                        <div class="admin-email"><?php echo e($admin['email']); ?></div>
                    </div>
                </div>
            </div>
            <nav>
                <ul class="nav-menu">
                    <li class="nav-section">Dashboard</li>
                    <li class="nav-item"><a href="index.php" class="nav-link"><i class="fas fa-home"></i><span>Overview</span></a></li>
                    <li class="nav-section">Management</li>
                    <li class="nav-item"><a href="projects.php" class="nav-link"><i class="fas fa-project-diagram"></i><span>Projects</span></a></li>
                    <li class="nav-item"><a href="users.php" class="nav-link active"><i class="fas fa-users"></i><span>Users</span></a></li>
                    <li class="nav-item"><a href="transactions.php" class="nav-link"><i class="fas fa-exchange-alt"></i><span>Transactions</span></a></li>
                    <li class="nav-item"><a href="plans.php" class="nav-link"><i class="fas fa-tags"></i><span>Payment Plans</span></a></li>
                    <li class="nav-item"><a href="partners.php" class="nav-link"><i class="fas fa-handshake"></i><span>Partners</span></a></li>
                    <li class="nav-section">Administration</li>
                    <li class="nav-item"><a href="admin-members.php" class="nav-link"><i class="fas fa-user-shield"></i><span>Admin Members</span></a></li>
                    <li class="nav-item"><a href="audit-logs.php" class="nav-link"><i class="fas fa-history"></i><span>Audit Logs</span></a></li>
                    <li class="sidebar-footer">
                        <ul class="nav-menu">
                            <li class="nav-item"><a href="logout.php" class="nav-link"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <div class="page-header">
                <div class="page-header-left">
                    <button class="hamburger" onclick="toggleSidebar()" aria-label="Toggle menu"><i class="fas fa-bars"></i></button>
                    <div class="page-title">
                        <h1>User Management</h1>
                        <p>Manage user accounts, view contributions, and oversee partnerships</p>
                    </div>
                </div>
            </div>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo e($success); ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo e($error); ?></div>
            <?php endif; ?>
            
            <?php if ($action === 'view' && $user): ?>
                <!-- User Detail View -->
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">User Details</h2>
                        <a href="users.php" class="btn btn-secondary btn-sm">Back to List</a>
                    </div>
                    <div class="card-body">
                        <div class="form-row">
                            <div>
                                <h3 class="section-title">Account Information</h3>
                                <table style="width: 100%;">
                                    <tr><td style="padding: 8px 16px;"><strong>Email:</strong></td><td style="padding: 8px;"><?php echo e($user['email']); ?></td></tr>
                                    <tr><td style="padding: 8px 16px;"><strong>Name:</strong></td><td style="padding: 8px;"><?php echo e($user['first_name'] . ' ' . $user['last_name']); ?></td></tr>
                                    <tr><td style="padding: 8px 16px;"><strong>Phone:</strong></td><td style="padding: 8px;"><?php echo e($user['phone'] ?? 'N/A'); ?></td></tr>
                                    <tr><td style="padding: 8px 16px;"><strong>Member Since:</strong></td><td style="padding: 8px;"><?php echo formatDate($user['created_at']); ?></td></tr>
                                    <tr><td style="padding: 8px 16px;"><strong>Last Login:</strong></td><td style="padding: 8px;"><?php echo $user['last_login'] ? formatDate($user['last_login']) : 'Never'; ?></td></tr>
                                    <tr><td style="padding: 8px 16px;"><strong>Status:</strong></td><td style="padding: 8px;"><span class="status-badge <?php echo $user['is_active'] ? 'status-active' : 'status-inactive'; ?>"><?php echo $user['is_active'] ? 'Active' : 'Inactive'; ?></span></td></tr>
                                </table>
                            </div>
                            <div>
                                <h3 class="section-title">Address</h3>
                                <p style="color: var(--text-secondary); line-height: 1.6;">
                                    <?php echo e($user['address_line1'] ?? ''); ?><br>
                                    <?php echo e($user['address_line2'] ?? ''); ?><br>
                                    <?php echo e($user['city'] . ', ' . $user['state'] . ' ' . $user['postal_code']); ?><br>
                                    <?php echo e($user['country']); ?>
                                </p>
                            </div>
                        </div>
                        
                        <div class="section">
                            <h3 class="section-title">Account Actions</h3>
                            <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                                <button class="btn btn-secondary btn-sm" onclick="openEditProfileModal()">
                                    <i class="fas fa-edit"></i> Edit Profile
                                </button>
                                <button class="btn btn-secondary btn-sm" onclick="openResetPasswordModal()">
                                    <i class="fas fa-key"></i> Reset Password
                                </button>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                    <input type="hidden" name="action" value="toggle_status">
                                    <input type="hidden" name="is_active" value="<?php echo $user['is_active'] ? '0' : '1'; ?>">
                                    <button type="submit" class="btn btn-sm <?php echo $user['is_active'] ? 'btn-danger' : 'btn-secondary'; ?>">
                                        <i class="fas fa-<?php echo $user['is_active'] ? 'pause' : 'play'; ?>"></i>
                                        <?php echo $user['is_active'] ? 'Pause Account' : 'Activate Account'; ?>
                                    </button>
                                </form>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this user? This action cannot be undone.')">
                                        <i class="fas fa-trash"></i> Delete User
                                    </button>
                                </form>
                            </div>
                        </div>
                        
                        
                        <!-- Total Giving -->
                        <div class="section">
                            <h3 class="section-title">Total Giving</h3>
                            <div style="font-size: 36px; font-weight: 700; color: var(--success);">
                                <?php echo formatCurrency($userTransactions ? array_sum(array_column($userTransactions, 'amount')) : 0); ?>
                            </div>
                            <div style="color: var(--text-secondary); margin-top: 8px;">
                                <?php echo count($userTransactions); ?> transactions
                            </div>
                        </div>
                        
                        <!-- Recent Transactions -->
                        <?php if (!empty($userTransactions)): ?>
                        <div class="section">
                            <h3 class="section-title">Recent Transactions</h3>
                            <?php foreach ($userTransactions as $transaction): ?>
                                <div class="transaction-item">
                                    <div>
                                        <strong><?php echo e($transaction['category']); ?></strong>
                                        <?php if ($transaction['project_title']): ?>
                                            <br><small style="color: var(--text-secondary);"><?php echo e($transaction['project_title']); ?></small>
                                        <?php endif; ?>
                                    </div>
                                    <div style="text-align: right;">
                                        <div class="transaction-amount"><?php echo formatCurrency($transaction['amount']); ?></div>
                                        <small style="color: var(--text-muted);"><?php echo formatDate($transaction['transaction_date']); ?></small>
                                    </div>
                                    <button class="btn btn-sm" onclick="viewReceipt('<?php echo e($transaction['transaction_reference']); ?>')" style="padding: 6px 12px;">
                                        <i class="fas fa-file-pdf"></i> Receipt
                                    </button>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Active Pledges -->
                        <?php if (!empty($userPledges)): ?>
                        <div class="section">
                            <h3 class="section-title">Active Pledges</h3>
                            <?php foreach ($userPledges as $pledge): ?>
                                <div class="pledge-item">
                                    <div>
                                        <strong><?php echo e($pledge['pledge_title'] ?? 'Pledge'); ?></strong>
                                        <br><small style="color: var(--text-secondary);"><?php echo e($pledge['frequency']); ?> • <?php echo formatCurrency($pledge['total_amount']); ?></small>
                                    </div>
                                    <div style="text-align: right;">
                                        <div style="font-weight: 600; color: var(--gold-dark);"><?php echo formatCurrency($pledge['remaining_amount']); ?> remaining</div>
                                        <small style="color: var(--text-muted);"><?php echo formatDate($pledge['start_date']); ?> - <?php echo $pledge['end_date'] ? formatDate($pledge['end_date']) : 'Ongoing'; ?></small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Projects Participated -->
                        <?php if (!empty($userProjects)): ?>
                        <div class="section">
                            <h3 class="section-title">Projects Participated</h3>
                            <?php foreach ($userProjects as $project): ?>
                                <div class="project-item">
                                    <div>
                                        <strong><?php echo e($project['title']); ?></strong>
                                        <br><small style="color: var(--text-secondary);"><?php echo e($project['category']); ?></small>
                                    </div>
                                    <div style="text-align: right;">
                                        <div style="font-weight: 600; color: var(--success);"><?php echo formatCurrency($project['total_contributed']); ?></div>
                                        <small style="color: var(--text-muted);"><?php echo $project['contribution_count']; ?> contributions</small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
            <?php else: ?>
                <!-- Users List -->
                <div class="metrics-grid">
                    <div class="metric-card">
                        <div class="metric-title">Total Users</div>
                        <div class="metric-value"><?php echo number_format($totalUsers); ?></div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-title">Total Given</div>
                        <div class="metric-value"><?php echo formatCurrency($totalGiven); ?></div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-title">Active Pledges</div>
                        <div class="metric-value"><?php echo array_sum(array_column($users, 'active_pledges')); ?></div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-title">Total Transactions</div>
                        <div class="metric-value"><?php echo array_sum(array_column($users, 'transaction_count')); ?></div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">All Users</h2>
                    </div>
                    <div class="card-body">
                        <div class="table-container">
                            <table>
                                <thead>
                                    <tr>
                                        <th>User</th>
                                        <th>Email</th>
                                        <th>Total Given</th>
                                        <th>Transactions</th>
                                        <th>Pledges</th>
                                        <th>Status</th>
                                        <th>Joined</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($users as $user): ?>
                                        <tr onclick="window.location='users.php?action=view&id=<?php echo $user['user_id']; ?>'">
                                            <td>
                                                <div style="display: flex; align-items: center; gap: 12px;">
                                                    <div class="user-avatar">
                                                        <?php echo strtoupper(substr($user['first_name'], 0, 1) . substr($user['last_name'], 0, 1)); ?>
                                                    </div>
                                                    <div>
                                                        <strong><?php echo e($user['first_name'] . ' ' . $user['last_name']); ?></strong>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo e($user['email']); ?></td>
                                            <td style="color: var(--success); font-weight: 600;"><?php echo formatCurrency($user['total_given']); ?></td>
                                            <td><?php echo number_format($user['transaction_count']); ?></td>
                                            <td><?php echo number_format($user['active_pledges']); ?></td>
                                            <td>
                                                <span class="status-badge <?php echo $user['is_active'] ? 'status-active' : 'status-inactive'; ?>">
                                                    <?php echo $user['is_active'] ? 'Active' : 'Inactive'; ?>
                                                </span>
                                            </td>
                                            <td><?php echo formatDate($user['created_at']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </main>
    </div>
    
    <!-- Edit Profile Modal -->
    <div class="modal-overlay" id="editProfileModal">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title">Edit Profile</h3>
                <button class="modal-close" onclick="closeEditProfileModal()">&times;</button>
            </div>
            <form method="POST" id="editProfileForm">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                <input type="hidden" name="action" value="edit_profile">
                <div class="modal-body">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">First Name</label>
                            <input type="text" name="first_name" class="form-input" value="<?php echo e($user['first_name']); ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="last_name" class="form-input" value="<?php echo e($user['last_name']); ?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Phone</label>
                            <input type="text" name="phone" class="form-input" value="<?php echo e($user['phone']); ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-input" value="<?php echo e($user['email']); ?>" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Address Line 1</label>
                        <input type="text" name="address_line1" class="form-input" value="<?php echo e($user['address_line1']); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Address Line 2</label>
                        <input type="text" name="address_line2" class="form-input" value="<?php echo e($user['address_line2']); ?>">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">City</label>
                            <input type="text" name="city" class="form-input" value="<?php echo e($user['city']); ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">State</label>
                            <input type="text" name="state" class="form-input" value="<?php echo e($user['state']); ?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Postal Code</label>
                            <input type="text" name="postal_code" class="form-input" value="<?php echo e($user['postal_code']); ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Country</label>
                            <input type="text" name="country" class="form-input" value="<?php echo e($user['country']); ?>">
                        </div>
                    </div>
                </div>
                <div style="padding: 20px 24px; border-top: 1px solid rgba(0,0,0,0.05); display: flex; gap: 12px; justify-content: flex-end;">
                    <button type="button" class="btn btn-secondary" onclick="closeEditProfileModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Reset Password Modal -->
    <div class="modal-overlay" id="resetPasswordModal">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title">Reset Password</h3>
                <button class="modal-close" onclick="closeResetPasswordModal()">&times;</button>
            </div>
            <form method="POST" id="resetPasswordForm">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                <input type="hidden" name="action" value="reset_password">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">New Password (minimum 8 characters)</label>
                        <input type="password" name="new_password" class="form-input" required>
                    </div>
                </div>
                <div style="padding: 20px 24px; border-top: 1px solid rgba(0,0,0,0.05); display: flex; gap: 12px; justify-content: flex-end;">
                    <button type="button" class="btn btn-secondary" onclick="closeResetPasswordModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Reset Password</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function viewReceipt(ref) {
            window.open('api/receipt.php?ref=' + encodeURIComponent(ref), '_blank');
        }
        
        function openEditProfileModal() {
            document.getElementById('editProfileModal').classList.add('active');
        }
        
        function closeEditProfileModal() {
            document.getElementById('editProfileModal').classList.remove('active');
        }
        
        function openResetPasswordModal() {
            document.getElementById('resetPasswordModal').classList.add('active');
        }
        
        function closeResetPasswordModal() {
            document.getElementById('resetPasswordModal').classList.remove('active');
        }
        
        // Close modal when clicking outside
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('modal-overlay')) {
                closeEditProfileModal();
                closeResetPasswordModal();
            }
        });
    </script>

    <!-- Responsive sidebar JS -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>
    <script>
        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('open');
            document.getElementById('sidebarOverlay').classList.toggle('active');
        }
        function closeSidebar() {
            document.querySelector('.sidebar').classList.remove('open');
            document.getElementById('sidebarOverlay').classList.remove('active');
        }
        document.querySelectorAll('.nav-link').forEach(function(link) {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 1024) closeSidebar();
            });
        });
    </script>

</body>
</html>
