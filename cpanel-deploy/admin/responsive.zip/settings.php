<?php
/**
 * Admin Settings Page
 * Bright Light Ministry Int'l Partners Portal
 */

session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Include admin config
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/database.php';

$db = Database::getInstance();

// Handle form submission
$successMessage = '';
$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings = [
        'recaptcha_site_key' => trim($_POST['recaptcha_site_key'] ?? ''),
        'recaptcha_secret_key' => trim($_POST['recaptcha_secret_key'] ?? ''),
        'support_email' => trim($_POST['support_email'] ?? ''),
        'support_phone' => trim($_POST['support_phone'] ?? ''),
        'auto_resolve_days' => (int)($_POST['auto_resolve_days'] ?? 7),
        'email_notifications' => isset($_POST['email_notifications']) ? '1' : '0'
    ];
    
    try {
        foreach ($settings as $key => $value) {
            $sql = "INSERT INTO system_settings (setting_key, setting_value, setting_type) 
                    VALUES (:key, :value, 'text') 
                    ON DUPLICATE KEY UPDATE setting_value = :value";
            
            $stmt = $db->getConnection()->prepare($sql);
            $stmt->execute([
                ':key' => $key,
                ':value' => $value
            ]);
        }
        
        $successMessage = 'Settings saved successfully!';
    } catch (Exception $e) {
        error_log("Settings error: " . $e->getMessage());
        $errorMessage = 'An error occurred while saving settings.';
    }
}

// Get current settings
$settings = [];
$result = $db->getConnection()->query("SELECT * FROM system_settings");
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Settings — Admin Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
  body { font-family: 'Inter', sans-serif; }
</style>
</head>
<body class="bg-gray-100">
<style>
.sidebar-overlay {
    display: none; position: fixed; inset: 0;
    background: rgba(0,0,0,0.5); z-index: 40;
}
.sidebar-overlay.active { display: block; }
@media (max-width: 1024px) {
    .sidebar-mobile-hidden { transform: translateX(-100%); position: fixed !important;
        top: 0; bottom: 0; left: 0; z-index: 50; transition: transform 0.3s ease; }
    .sidebar-mobile-hidden.open { transform: translateX(0); }
    .mobile-hamburger-bar { display: flex !important; }
}
.mobile-hamburger-bar { display: none; align-items: center; gap: 12px;
    background: white; padding: 12px 16px; border-bottom: 1px solid #e5e7eb; }
.mobile-hamburger-bar button { background: none; border: none; font-size: 22px; cursor: pointer; color: #1f2937; }
</style>

<div class="flex h-screen">

<!-- Sidebar -->
<div id="sidebarWrapper">
<?php include 'includes/sidebar.php'; ?>
</div>

<!-- Overlay -->
<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSettingsSidebar()"></div>
<!-- Main Content -->
<div class="flex-1 flex flex-col overflow-hidden">
<div class="mobile-hamburger-bar" id="mobileBar">
    <button onclick="toggleSettingsSidebar()" aria-label="Menu">&#9776;</button>
    <span style="font-weight:600;color:#1f2937;">Settings</span>
</div>

<!-- Top Bar -->
<?php include 'includes/topbar.php'; ?>

<!-- Main Content Area -->
<main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-6">

  <!-- Page Header -->
  <div class="mb-6">
    <h1 class="text-2xl font-bold text-gray-800">Settings</h1>
    <p class="text-gray-600 mt-1">Configure system settings and preferences</p>
  </div>

  <!-- Success/Error Messages -->
  <?php if ($successMessage): ?>
  <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
    <?php echo htmlspecialchars($successMessage); ?>
  </div>
  <?php endif; ?>

  <?php if ($errorMessage): ?>
  <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
    <?php echo htmlspecialchars($errorMessage); ?>
  </div>
  <?php endif; ?>

  <!-- Settings Form -->
  <div class="bg-white rounded-lg shadow p-6">
    <form method="POST" class="space-y-6">
      
      <!-- reCAPTCHA Settings -->
      <div>
        <h2 class="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <svg class="w-5 h-5 text-gold" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
          reCAPTCHA Configuration
        </h2>
        <p class="text-sm text-gray-600 mb-4">Configure Google reCAPTCHA to prevent spam on the support form.</p>
        
        <div class="grid md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">
              Site Key
            </label>
            <input type="text" name="recaptcha_site_key" 
              value="<?php echo htmlspecialchars($settings['recaptcha_site_key'] ?? ''); ?>"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent outline-none"
              placeholder="6LcXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
            />
            <p class="text-xs text-gray-500 mt-1">Get your site key from <a href="https://www.google.com/recaptcha/admin" target="_blank" class="text-gold hover:underline">Google reCAPTCHA Admin</a></p>
          </div>
          
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">
              Secret Key
            </label>
            <input type="password" name="recaptcha_secret_key" 
              value="<?php echo htmlspecialchars($settings['recaptcha_secret_key'] ?? ''); ?>"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent outline-none"
              placeholder="6LcXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
            />
          </div>
        </div>
      </div>

      <hr class="border-gray-200">

      <!-- Support Contact Settings -->
      <div>
        <h2 class="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <svg class="w-5 h-5 text-gold" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
          Support Contact Information
        </h2>
        <p class="text-sm text-gray-600 mb-4">These details will be displayed on the support page.</p>
        
        <div class="grid md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">
              Support Email
            </label>
            <input type="email" name="support_email" 
              value="<?php echo htmlspecialchars($settings['support_email'] ?? 'support@brightlightministry.org'); ?>"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent outline-none"
            />
          </div>
          
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">
              Support Phone
            </label>
            <input type="text" name="support_phone" 
              value="<?php echo htmlspecialchars($settings['support_phone'] ?? '+234 800 SUPPORT'); ?>"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent outline-none"
            />
          </div>
        </div>
      </div>

      <hr class="border-gray-200">

      <!-- Ticket Settings -->
      <div>
        <h2 class="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <svg class="w-5 h-5 text-gold" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
          Ticket Management
        </h2>
        
        <div class="grid md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">
              Auto-Resolve Days
            </label>
            <input type="number" name="auto_resolve_days" 
              value="<?php echo htmlspecialchars($settings['auto_resolve_days'] ?? 7); ?>"
              min="1" max="365"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent outline-none"
            />
            <p class="text-xs text-gray-500 mt-1">Tickets will be auto-resolved after this many days of inactivity</p>
          </div>
          
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">
              Email Notifications
            </label>
            <div class="flex items-center gap-3">
              <label class="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" name="email_notifications" 
                  value="1" 
                  <?php echo ($settings['email_notifications'] ?? '1') === '1' ? 'checked' : ''; ?>
                  class="sr-only peer"
                />
                <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-gold/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gold"></div>
                <span class="ml-3 text-sm font-medium text-gray-700">Enable</span>
              </label>
            </div>
            <p class="text-xs text-gray-500 mt-1">Send email notifications when new tickets are created</p>
          </div>
        </div>
      </div>

      <!-- Submit Button -->
      <div class="flex justify-end gap-3 pt-4">
        <button type="button" onclick="window.location.href='index.php'" 
          class="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition">
          Cancel
        </button>
        <button type="submit" 
          class="px-6 py-2 bg-gold hover:bg-goldsoft text-deep font-semibold rounded-lg transition">
          Save Settings
        </button>
      </div>

    </form>
  </div>

</main>

</div>
</div>

<script>
function toggleSettingsSidebar() {
    var sidebar = document.querySelector('#sidebarWrapper > aside, #sidebarWrapper > div');
    var overlay = document.getElementById('sidebarOverlay');
    if (sidebar) {
        sidebar.classList.toggle('sidebar-mobile-hidden');
        sidebar.classList.toggle('open');
        overlay.classList.toggle('active');
    }
}
function closeSettingsSidebar() {
    var sidebar = document.querySelector('#sidebarWrapper > aside, #sidebarWrapper > div');
    var overlay = document.getElementById('sidebarOverlay');
    if (sidebar) {
        sidebar.classList.add('sidebar-mobile-hidden');
        sidebar.classList.remove('open');
        overlay.classList.remove('active');
    }
}
if (window.innerWidth <= 1024) {
    var sidebar = document.querySelector('#sidebarWrapper > aside, #sidebarWrapper > div');
    if (sidebar) sidebar.classList.add('sidebar-mobile-hidden');
}
window.addEventListener('resize', function() {
    var sidebar = document.querySelector('#sidebarWrapper > aside, #sidebarWrapper > div');
    if (!sidebar) return;
    if (window.innerWidth > 1024) {
        sidebar.classList.remove('sidebar-mobile-hidden', 'open');
        document.getElementById('sidebarOverlay').classList.remove('active');
    } else {
        if (!sidebar.classList.contains('open')) sidebar.classList.add('sidebar-mobile-hidden');
    }
});
</script>
</body>
</html>