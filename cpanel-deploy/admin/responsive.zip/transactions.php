<?php
/**
 * Transaction Management Page
 * Church Financial Partnership System
 */

require_once __DIR__ . '/includes/config.php';

// Require authentication
$admin = requireAdmin();

$db = Database::getInstance();

// Get filter parameters
$statusFilter = $_GET['status'] ?? 'all';
$dateFrom = $_GET['date_from'] ?? null;
$dateTo = $_GET['date_to'] ?? null;
$userFilter = $_GET['user_id'] ?? null;
$projectFilter = $_GET['project_id'] ?? null;
$search = $_GET['search'] ?? null;
$page = intval($_GET['page'] ?? 1);
$perPage = ITEMS_PER_PAGE;

// Build query
$whereClauses = ["t.status != 'refunded'"];
$params = [];

if ($statusFilter !== 'all') {
    $whereClauses[] = "t.status = :status";
    $params['status'] = $statusFilter;
}

if ($dateFrom) {
    $whereClauses[] = "t.transaction_date >= :date_from";
    $params['date_from'] = $dateFrom . ' 00:00:00';
}

if ($dateTo) {
    $whereClauses[] = "t.transaction_date <= :date_to";
    $params['date_to'] = $dateTo . ' 23:59:59';
}

if ($userFilter) {
    $whereClauses[] = "t.user_id = :user_id";
    $params['user_id'] = $userFilter;
}

if ($projectFilter) {
    $whereClauses[] = "t.project_id = :project_id";
    $params['project_id'] = $projectFilter;
}

if ($search) {
    $whereClauses[] = "(t.transaction_reference LIKE :search OR u.email LIKE :search2 OR u.first_name LIKE :search3 OR u.last_name LIKE :search4)";
    $searchParam = "%$search%";
    $params['search'] = $searchParam;
    $params['search2'] = $searchParam;
    $params['search3'] = $searchParam;
    $params['search4'] = $searchParam;
}

$whereSql = implode(' AND ', $whereClauses);

// Get total count
$totalCount = $db->fetchOne(
    "SELECT COUNT(*) as count FROM transactions t
     INNER JOIN users u ON t.user_id = u.user_id
     WHERE $whereSql",
    $params
)['count'];

$totalPages = ceil($totalCount / $perPage);
$offset = ($page - 1) * $perPage;

// Get transactions
$transactions = $db->fetchAll(
    "SELECT t.*, u.first_name, u.last_name, u.email, p.title as project_title, pm.card_type, pm.last_four_digits
     FROM transactions t
     INNER JOIN users u ON t.user_id = u.user_id
     LEFT JOIN projects p ON t.project_id = p.project_id
     LEFT JOIN payment_methods pm ON t.payment_method_id = pm.payment_method_id
     WHERE $whereSql
     ORDER BY t.transaction_date DESC
     LIMIT :limit OFFSET :offset",
    array_merge($params, ['limit' => $perPage, 'offset' => $offset])
);

// Get statistics
$stats = $db->fetchOne(
    "SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN t.status = 'completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN t.status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN t.status = 'failed' THEN 1 ELSE 0 END) as failed,
        COALESCE(SUM(CASE WHEN t.status = 'completed' THEN t.amount ELSE 0 END), 0) as total_amount
     FROM transactions t
     WHERE $whereSql",
    $params
);

// Get unique users count
$uniqueUsers = $db->fetchOne(
    "SELECT COUNT(DISTINCT t.user_id) as count FROM transactions t
     WHERE $whereSql",
    $params
)['count'];

// Get recent transactions for sidebar
$recentTransactions = $db->fetchAll(
    "SELECT t.*, u.first_name, u.last_name
     FROM transactions t
     INNER JOIN users u ON t.user_id = u.user_id
     WHERE t.status = 'completed'
     ORDER BY t.transaction_date DESC
     LIMIT 5"
);

// Get active projects for filter
$activeProjects = $db->fetchAll("SELECT project_id, title FROM projects WHERE is_active = TRUE ORDER BY title");

// Get date range stats
$monthlyStats = $db->fetchOne(
    "SELECT 
        COALESCE(SUM(amount), 0) as monthly_total,
        COUNT(*) as monthly_count
     FROM transactions 
     WHERE MONTH(transaction_date) = MONTH(NOW()) 
     AND YEAR(transaction_date) = YEAR(NOW()) 
     AND status = 'completed'"
);

$yearlyStats = $db->fetchOne(
    "SELECT 
        COALESCE(SUM(amount), 0) as yearly_total,
        COUNT(*) as yearly_count
     FROM transactions 
     WHERE YEAR(transaction_date) = YEAR(NOW()) 
     AND status = 'completed'"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transactions Management - Admin Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;0,9..144,700;1,9..144,500&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="form-styles.css" rel="stylesheet">
    <style>
        :root {
            --gold: #C9A24B;
            --gold-light: #E7D9B4;
            --gold-dark: #A8863A;
            --dark: #0F1B2D;
            --deep: #122137;
            --cream: #FAF6EF;
            --cream-light: #F5F0E8;
            --text-primary: #0F1B2D;
            --text-secondary: rgba(15, 27, 45, 0.55);
            --text-muted: rgba(15, 27, 45, 0.4);
            --success: #28a745;
            --warning: #ffc107;
            --danger: #dc3545;
            --info: #17a2b8;
            --radius-sm: 14px;
            --radius-md: 14px;
            --radius-lg: 24px;
            --shadow-sm: 0 2px 4px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 12px rgba(0,0,0,0.1);
            --shadow-lg: 0 8px 24px rgba(0,0,0,0.15);
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Inter', sans-serif; 
            background: #FAF6EF; 
            color: #0F1B2D;
            min-height: 100vh;
        }
        h1, h2, h3, h4 { font-family: 'Fraunces', serif; }
        .font-serif { font-family: 'Fraunces', serif; }
        
        .layout { display: flex; min-height: 100vh; }
        
        .sidebar {
            position: fixed; left: 0; top: 0; bottom: 0; width: 280px;
            background: var(--dark); color: white; padding: 24px 0; overflow-y: auto; z-index: 1000;
        }
        .sidebar-header { padding: 0 24px 24px; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar-logo { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
        .sidebar-logo-icon { width: 40px; height: 40px; background: var(--gold); border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 20px; color: var(--dark); }
        .sidebar-logo-text { font-family: 'Playfair Display', serif; font-size: 14px; }
        .sidebar-logo-text span { display: block; font-size: 10px; font-family: 'Inter', sans-serif; color: rgba(255,255,255,0.6); }
        .admin-info { display: flex; align-items: center; gap: 12px; padding: 16px 24px; background: rgba(255,255,255,0.05); border-radius: 12px; margin: 16px 12px; }
        .admin-avatar { width: 40px; height: 40px; background: var(--gold); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; color: var(--dark); }
        .admin-details { flex: 1; }
        .admin-name { font-size: 12px; font-weight: 500; }
        .admin-email { font-size: 10px; color: rgba(255,255,255,0.5); }
        .nav-menu { list-style: none; padding: 0 12px; }
        .nav-item { margin: 4px 0; }
        .nav-link { display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: rgba(255,255,255,0.7); text-decoration: none; border-radius: 12px; transition: all 0.2s; font-size: 14px; }
        .nav-link:hover, .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .nav-link i { width: 20px; text-align: center; }
        .nav-section { padding: 16px 12px 8px; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; color: rgba(255,255,255,0.4); }
        .sidebar-footer { position: absolute; bottom: 0; left: 0; right: 0; padding: 16px 12px; border-top: 1px solid rgba(255,255,255,0.1); }
        .sidebar-footer .nav-link:hover { color: var(--danger); }
        
        .main-content { margin-left: 280px; flex: 1; padding: 32px; }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; }
        .page-title h1 { font-size: 28px; color: var(--dark); margin-bottom: 4px; }
        .page-title p { color: var(--text-secondary); font-size: 14px; }
        .page-actions { display: flex; gap: 12px; }
        
        .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border-radius: 6px; font-size: 14px; font-weight: 500; text-decoration: none; cursor: pointer; border: none; transition: all 0.2s; }
        .btn-primary { background: var(--gold); color: var(--dark); }
        .btn-primary:hover { background: var(--gold-dark); }
        .btn-secondary { background: white; color: var(--text-primary); border: 1px solid rgba(0,0,0,0.1); }
        .btn-secondary:hover { background: var(--cream-light); }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        
        .card { background: white; border-radius: 16px; box-shadow: var(--shadow-sm); overflow: hidden; }
        .card-header { display: flex; justify-content: space-between; align-items: center; padding: 20px 24px; border-bottom: 1px solid rgba(0,0,0,0.05); }
        .card-title { font-size: 18px; color: var(--dark); }
        .card-body { padding: 24px; }
        
        .metrics-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px; margin-bottom: 32px; }
        .metric-card { background: white; border-radius: 16px; padding: 24px; box-shadow: var(--shadow-sm); }
        .metric-title { font-size: 13px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }
        .metric-value { font-size: 32px; font-weight: 700; color: var(--dark); }
        .metric-subtitle { font-size: 12px; color: var(--text-muted); margin-top: 4px; }
        
        .filter-bar { background: white; border-radius: 16px; padding: 24px; margin-bottom: 24px; box-shadow: var(--shadow-sm); }
        .filter-grid { display: grid; grid-template-columns: repeat(6, 1fr); gap: 16px; align-items: end; }
        .filter-group { display: flex; flex-direction: column; gap: 6px; }
        .filter-label { font-size: 12px; font-weight: 500; color: var(--text-secondary); }
        .filter-input, .filter-select { padding: 10px 14px; border: 1px solid rgba(0,0,0,0.1); border-radius: 6px; font-size: 14px; }
        .filter-input:focus, .filter-select:focus { outline: none; border-color: var(--gold); }
        
        .table-container { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 14px 16px; text-align: left; border-bottom: 1px solid rgba(0,0,0,0.05); }
        th { font-size: 12px; text-transform: uppercase; letter-spacing: 1px; color: var(--text-secondary); font-weight: 500; }
        tr:hover { background: var(--cream-light); }
        
        .status-badge { padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 500; }
        .status-completed { background: rgba(40, 167, 69, 0.1); color: var(--success); }
        .status-pending { background: rgba(255, 193, 7, 0.1); color: #b7950b; }
        .status-failed { background: rgba(220, 53, 69, 0.1); color: var(--danger); }
        
        .amount { font-weight: 600; color: var(--success); }
        
        .pagination { display: flex; justify-content: center; align-items: center; gap: 8px; margin-top: 24px; }
        .page-btn { padding: 8px 14px; border: 1px solid rgba(0,0,0,0.1); border-radius: 6px; background: white; cursor: pointer; font-size: 14px; }
        .page-btn:hover:not(:disabled) { background: var(--cream-light); border-color: var(--gold); }
        .page-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .page-btn.active { background: var(--gold); border-color: var(--gold); color: var(--dark); }
        
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0; }
            .filter-grid { grid-template-columns: repeat(3, 1fr); }
        }
        @media (max-width: 768px) {
            .metrics-grid { grid-template-columns: repeat(2, 1fr); }
            .filter-grid { grid-template-columns: 1fr; }
        }
    
        /* ── Responsive sidebar & hamburger ── */
        .sidebar { transition: transform 0.3s ease; }
        .sidebar.open { transform: translateX(0) !important; }

        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999;
        }
        .sidebar-overlay.active { display: block; }

        .hamburger {
            display: none;
            background: none;
            border: none;
            font-size: 22px;
            color: var(--dark, #0F1B2D);
            cursor: pointer;
            padding: 6px 10px;
            border-radius: 6px;
            line-height: 1;
            flex-shrink: 0;
        }
        .hamburger:hover { background: rgba(0,0,0,0.05); }

        .page-header-left {
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }

        @media (max-width: 1024px) {
            .hamburger { display: flex; align-items: center; justify-content: center; }
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0 !important; }
        }

        @media (max-width: 768px) {
            .main-content { padding: 16px !important; }
            .page-header { flex-wrap: wrap; gap: 12px; margin-bottom: 20px !important; }
            .page-actions { width: 100%; justify-content: flex-end; }
            .page-title h1 { font-size: 22px !important; }
            .metrics-grid { grid-template-columns: repeat(2, 1fr) !important; gap: 12px !important; }
            .filter-grid { grid-template-columns: 1fr !important; }
            .form-row { grid-template-columns: 1fr !important; }
            .metric-value { font-size: 24px !important; }
            .card-header, .card-body { padding: 16px !important; }
            .modal { width: 95% !important; border-radius: 12px !important; }
            .table-container { overflow-x: auto; }
            .btn-label { display: none; }
        }

        @media (max-width: 480px) {
            .metrics-grid { grid-template-columns: 1fr !important; }
            .main-content { padding: 12px !important; }
            .page-title h1 { font-size: 19px !important; }
        }

    </style>
</head>
<body>
    <div class="layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <div class="sidebar-logo-icon">✝</div>
                    <div class="sidebar-logo-text">
                        Bright Light Ministry Int'l
                        <span>Admin Dashboard</span>
                    </div>
                </div>
                <div class="admin-info">
                    <div class="admin-avatar"><?php echo strtoupper(substr($admin['first_name'], 0, 1) . substr($admin['last_name'], 0, 1)); ?></div>
                    <div class="admin-details">
                        <div class="admin-name"><?php echo e($admin['first_name'] . ' ' . $admin['last_name']); ?></div>
                        <div class="admin-email"><?php echo e($admin['email']); ?></div>
                    </div>
                </div>
            </div>
            <nav>
                <ul class="nav-menu">
                    <li class="nav-section">Dashboard</li>
                    <li class="nav-item"><a href="index.php" class="nav-link"><i class="fas fa-home"></i><span>Overview</span></a></li>
                    <li class="nav-section">Management</li>
                    <li class="nav-item"><a href="projects.php" class="nav-link"><i class="fas fa-project-diagram"></i><span>Projects</span></a></li>
                    <li class="nav-item"><a href="users.php" class="nav-link"><i class="fas fa-users"></i><span>Users</span></a></li>
                    <li class="nav-item"><a href="transactions.php" class="nav-link active"><i class="fas fa-exchange-alt"></i><span>Transactions</span></a></li>
                    <li class="nav-item"><a href="plans.php" class="nav-link"><i class="fas fa-tags"></i><span>Payment Plans</span></a></li>
                    <li class="nav-item"><a href="partners.php" class="nav-link"><i class="fas fa-handshake"></i><span>Partners</span></a></li>
                    <li class="nav-section">Administration</li>
                    <li class="nav-item"><a href="admin-members.php" class="nav-link"><i class="fas fa-user-shield"></i><span>Admin Members</span></a></li>
                    <li class="nav-item"><a href="audit-logs.php" class="nav-link"><i class="fas fa-history"></i><span>Audit Logs</span></a></li>
                    <li class="sidebar-footer">
                        <ul class="nav-menu">
                            <li class="nav-item"><a href="logout.php" class="nav-link"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <div class="page-header">
                <div class="page-header-left">
                    <button class="hamburger" onclick="toggleSidebar()" aria-label="Toggle menu"><i class="fas fa-bars"></i></button>
                    <div class="page-title">
                        <h1>Transactions Management</h1>
                        <p>View, filter, and manage all transactions across the platform</p>
                    </div>
                </div>
                <div class="page-actions">
                    <a href="export.php?type=transactions" class="btn btn-secondary">
                        <i class="fas fa-download"></i><span class="btn-label"> Export CSV</span>
                    </a>
                </div>
            </div>
            
            <!-- Metrics Grid -->
            <div class="metrics-grid">
                <div class="metric-card">
                    <div class="metric-title">Total Transactions</div>
                    <div class="metric-value"><?php echo number_format($stats['total']); ?></div>
                    <div class="metric-subtitle"><?php echo number_format($uniqueUsers); ?> unique users</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">Total Amount</div>
                    <div class="metric-value"><?php echo formatCurrency($stats['total_amount']); ?></div>
                    <div class="metric-subtitle">Filtered range</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">This Month</div>
                    <div class="metric-value"><?php echo formatCurrency($monthlyStats['monthly_total']); ?></div>
                    <div class="metric-subtitle"><?php echo number_format($monthlyStats['monthly_count']); ?> transactions</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">This Year</div>
                    <div class="metric-value"><?php echo formatCurrency($yearlyStats['yearly_total']); ?></div>
                    <div class="metric-subtitle"><?php echo number_format($yearlyStats['yearly_count']); ?> transactions</div>
                </div>
            </div>
            
            <!-- Filter Bar -->
            <div class="filter-bar">
                <form method="GET" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    <div class="filter-grid">
                        <div class="filter-group">
                            <label class="filter-label">Status</label>
                            <select name="status" class="filter-select">
                                <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>All Status</option>
                                <option value="completed" <?php echo $statusFilter === 'completed' ? 'selected' : ''; ?>>Completed</option>
                                <option value="pending" <?php echo $statusFilter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="failed" <?php echo $statusFilter === 'failed' ? 'selected' : ''; ?>>Failed</option>
                            </select>
                        </div>
                        <div class="filter-group">
                            <label class="filter-label">From Date</label>
                            <input type="date" name="date_from" class="filter-input" value="<?php echo e($dateFrom); ?>">
                        </div>
                        <div class="filter-group">
                            <label class="filter-label">To Date</label>
                            <input type="date" name="date_to" class="filter-input" value="<?php echo e($dateTo); ?>">
                        </div>
                        <div class="filter-group">
                            <label class="filter-label">Project</label>
                            <select name="project_id" class="filter-select">
                                <option value="">All Projects</option>
                                <?php foreach ($activeProjects as $project): ?>
                                    <option value="<?php echo $project['project_id']; ?>" <?php echo $projectFilter == $project['project_id'] ? 'selected' : ''; ?>><?php echo e($project['title']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="filter-group">
                            <label class="filter-label">Search</label>
                            <input type="text" name="search" class="filter-input" placeholder="Email, ref..." value="<?php echo e($search); ?>">
                        </div>
                        <div class="filter-group">
                            <label class="filter-label">&nbsp;</label>
                            <button type="submit" class="btn btn-primary" style="width: 100%;">
                                <i class="fas fa-search"></i> Filter
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Transactions Table -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">All Transactions</h2>
                    <span style="color: var(--text-secondary); font-size: 14px;"><?php echo number_format($totalCount); ?> total records</span>
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>User</th>
                                    <th>Reference</th>
                                    <th>Category</th>
                                    <th>Project</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Payment</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($transactions)): ?>
                                    <tr>
                                        <td colspan="8" style="text-align: center; padding: 40px; color: var(--text-muted);">
                                            No transactions found matching your criteria.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($transactions as $transaction): ?>
                                        <tr>
                                            <td><?php echo formatDate($transaction['transaction_date'], 'M d, Y'); ?><br><small style="color: var(--text-muted);"><?php echo date('g:i A', strtotime($transaction['transaction_date'])); ?></small></td>
                                            <td>
                                                <strong><?php echo e($transaction['first_name'] . ' ' . $transaction['last_name']); ?></strong><br>
                                                <small style="color: var(--text-muted);"><?php echo e($transaction['email']); ?></small>
                                            </td>
                                            <td><code style="font-size: 11px;"><?php echo e($transaction['transaction_reference']); ?></code></td>
                                            <td><span class="status-badge status-completed"><?php echo e($transaction['category']); ?></span></td>
                                            <td><?php echo e($transaction['project_title'] ?? '-'); ?></td>
                                            <td class="amount"><?php echo formatCurrency($transaction['amount']); ?></td>
                                            <td>
                                                <span class="status-badge status-<?php echo $transaction['status']; ?>">
                                                    <?php echo ucfirst($transaction['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($transaction['card_type']): ?>
                                                    <?php echo e($transaction['card_type']); ?> •••• <?php echo e($transaction['last_four_digits']); ?>
                                                <?php else: ?>
                                                    <small style="color: var(--text-muted);">N/A</small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm" onclick="viewReceipt('<?php echo e($transaction['transaction_reference']); ?>')" style="padding: 6px 12px;">
                                                    <i class="fas fa-file-pdf"></i> Receipt
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <div class="pagination">
                            <button class="page-btn" onclick="goToPage(<?php echo $page - 1; ?>)" <?php echo $page <= 1 ? 'disabled' : ''; ?>>
                                <i class="fas fa-chevron-left"></i>
                            </button>
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <?php if ($i <= 5 || $i > $totalPages - 4 || abs($i - $page) <= 2): ?>
                                    <button class="page-btn <?php echo $i === $page ? 'active' : ''; ?>" onclick="goToPage(<?php echo $i; ?>)">
                                        <?php echo $i; ?>
                                    </button>
                                <?php elseif (abs($i - $page) <= 2): ?>
                                    <button class="page-btn" disabled>...</button>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <button class="page-btn" onclick="goToPage(<?php echo $page + 1; ?>)" <?php echo $page >= $totalPages ? 'disabled' : ''; ?>>
                                <i class="fas fa-chevron-right"></i>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    
    <script>
        function goToPage(page) {
            const params = new URLSearchParams(window.location.search);
            params.set('page', page);
            window.location.search = params.toString();
        }
        
        function viewReceipt(ref) {
            window.open('api/receipt.php?ref=' + encodeURIComponent(ref), '_blank');
        }
    </script>

    <!-- Responsive sidebar JS -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>
    <script>
        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('open');
            document.getElementById('sidebarOverlay').classList.toggle('active');
        }
        function closeSidebar() {
            document.querySelector('.sidebar').classList.remove('open');
            document.getElementById('sidebarOverlay').classList.remove('active');
        }
        document.querySelectorAll('.nav-link').forEach(function(link) {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 1024) closeSidebar();
            });
        });
    </script>

</body>
</html>