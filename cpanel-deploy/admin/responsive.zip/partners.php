<?php
/**
 * Partners Page - Active Recurring Contributors
 * Church Financial Partnership System
 */

require_once __DIR__ . '/includes/config.php';

// Require authentication
$admin = requireAdmin();

$db = Database::getInstance();

// Get filter parameters
$frequencyFilter = $_GET['frequency'] ?? 'all';
$statusFilter = $_GET['status'] ?? 'all';
$minAmount = $_GET['min_amount'] ?? null;
$page = intval($_GET['page'] ?? 1);
$perPage = ITEMS_PER_PAGE;

// Build query
$whereClauses = ["p.is_active = TRUE"];
$params = [];

if ($frequencyFilter !== 'all') {
    $whereClauses[] = "p.frequency = :frequency";
    $params['frequency'] = $frequencyFilter;
}

if ($statusFilter === 'active') {
    // Active: remaining > 0 and end_date is in future or null
    $whereClauses[] = "(p.remaining_amount > 0 AND (p.end_date IS NULL OR p.end_date > NOW()))";
} elseif ($statusFilter === 'completed') {
    // Completed: remaining = 0 or end_date in past
    $whereClauses[] = "(p.remaining_amount = 0 OR p.end_date < NOW())";
}

if ($minAmount !== null && $minAmount > 0) {
    $whereClauses[] = "p.total_amount >= :min_amount";
    $params['min_amount'] = floatval($minAmount);
}

$whereSql = implode(' AND ', $whereClauses);

// Get total count
$totalCount = $db->fetchOne(
    "SELECT COUNT(*) as count FROM pledges p
     INNER JOIN users u ON p.user_id = u.user_id
     WHERE $whereSql",
    $params
)['count'];

$totalPages = ceil($totalCount / $perPage);
$offset = ($page - 1) * $perPage;

// Get partners with their pledges
$partners = $db->fetchAll(
    "SELECT p.*, u.email, u.first_name, u.last_name, u.phone,
            (SELECT COUNT(*) FROM transactions t WHERE t.user_id = p.user_id AND t.status = 'completed') as total_transactions,
            (SELECT COALESCE(SUM(amount), 0) FROM transactions t WHERE t.user_id = p.user_id AND t.status = 'completed') as total_given
     FROM pledges p
     INNER JOIN users u ON p.user_id = u.user_id
     WHERE $whereSql
     ORDER BY p.created_at DESC
     LIMIT :limit OFFSET :offset",
    array_merge($params, ['limit' => $perPage, 'offset' => $offset])
);

// Get statistics
$stats = $db->fetchOne(
    "SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN p.remaining_amount > 0 AND (p.end_date IS NULL OR p.end_date > NOW()) THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN p.remaining_amount = 0 OR p.end_date < NOW() THEN 1 ELSE 0 END) as completed,
        COALESCE(SUM(p.total_amount), 0) as total_commitment,
        COALESCE(SUM(p.remaining_amount), 0) as remaining_commitment
     FROM pledges p
     INNER JOIN users u ON p.user_id = u.user_id
     WHERE $whereSql",
    $params
);

// Get frequency breakdown
$frequencyStats = $db->fetchAll(
    "SELECT frequency, 
            COUNT(*) as count,
            COALESCE(SUM(total_amount), 0) as total_amount
     FROM pledges p
     INNER JOIN users u ON p.user_id = u.user_id
     WHERE $whereSql
     GROUP BY frequency"
);

// Get top contributors
$topContributors = $db->fetchAll(
    "SELECT u.user_id, u.email, u.first_name, u.last_name,
            (SELECT COALESCE(SUM(amount), 0) FROM transactions t WHERE t.user_id = u.user_id AND t.status = 'completed') as total_given,
            (SELECT COUNT(*) FROM pledges p WHERE p.user_id = u.user_id AND p.is_active = TRUE) as active_pledges
     FROM users u
     WHERE u.is_active = TRUE
     ORDER BY total_given DESC
     LIMIT 10"
);

// Get upcoming renewals (next 30 days)
$upcomingRenewals = $db->fetchAll(
    "SELECT p.*, u.first_name, u.last_name
     FROM pledges p
     INNER JOIN users u ON p.user_id = u.user_id
     WHERE p.is_active = TRUE
     AND p.end_date IS NOT NULL
     AND p.end_date BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 30 DAY)
     ORDER BY p.end_date ASC
     LIMIT 10"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partners - Admin Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;0,9..144,700;1,9..144,500&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="form-styles.css" rel="stylesheet">
    <style>
        :root {
            --gold: #C9A24B;
            --gold-light: #E7D9B4;
            --gold-dark: #A8863A;
            --dark: #0F1B2D;
            --deep: #122137;
            --cream: #FAF6EF;
            --cream-light: #F5F0E8;
            --text-primary: #0F1B2D;
            --text-secondary: rgba(15, 27, 45, 0.55);
            --text-muted: rgba(15, 27, 45, 0.4);
            --success: #28a745;
            --warning: #ffc107;
            --danger: #dc3545;
            --info: #17a2b8;
            --radius-sm: 14px;
            --radius-md: 14px;
            --radius-lg: 24px;
            --shadow-sm: 0 2px 4px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 12px rgba(0,0,0,0.1);
            --shadow-lg: 0 8px 24px rgba(0,0,0,0.15);
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Inter', sans-serif; 
            background: #FAF6EF; 
            color: #0F1B2D;
            min-height: 100vh;
        }
        h1, h2, h3, h4 { font-family: 'Fraunces', serif; }
        .font-serif { font-family: 'Fraunces', serif; }
        
        .layout { display: flex; min-height: 100vh; }
        
        .sidebar {
            position: fixed; left: 0; top: 0; bottom: 0; width: 280px;
            background: var(--dark); color: white; padding: 24px 0; overflow-y: auto; z-index: 1000;
        }
        .sidebar-header { padding: 0 24px 24px; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar-logo { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
        .sidebar-logo-icon { width: 40px; height: 40px; background: var(--gold); border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 20px; color: var(--dark); }
        .sidebar-logo-text { font-family: 'Playfair Display', serif; font-size: 14px; }
        .sidebar-logo-text span { display: block; font-size: 10px; font-family: 'Inter', sans-serif; color: rgba(255,255,255,0.6); }
        .admin-info { display: flex; align-items: center; gap: 12px; padding: 16px 24px; background: rgba(255,255,255,0.05); border-radius: 12px; margin: 16px 12px; }
        .admin-avatar { width: 40px; height: 40px; background: var(--gold); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; color: var(--dark); }
        .admin-details { flex: 1; }
        .admin-name { font-size: 12px; font-weight: 500; }
        .admin-email { font-size: 10px; color: rgba(255,255,255,0.5); }
        .nav-menu { list-style: none; padding: 0 12px; }
        .nav-item { margin: 4px 0; }
        .nav-link { display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: rgba(255,255,255,0.7); text-decoration: none; border-radius: 12px; transition: all 0.2s; font-size: 14px; }
        .nav-link:hover, .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .nav-link i { width: 20px; text-align: center; }
        .nav-section { padding: 16px 12px 8px; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; color: rgba(255,255,255,0.4); }
        .sidebar-footer { position: absolute; bottom: 0; left: 0; right: 0; padding: 16px 12px; border-top: 1px solid rgba(255,255,255,0.1); }
        .sidebar-footer .nav-link:hover { color: var(--danger); }
        
        .main-content { margin-left: 280px; flex: 1; padding: 32px; }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; }
        .page-title h1 { font-size: 28px; color: var(--dark); margin-bottom: 4px; }
        .page-title p { color: var(--text-secondary); font-size: 14px; }
        .page-actions { display: flex; gap: 12px; }
        
        .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border-radius: 6px; font-size: 14px; font-weight: 500; text-decoration: none; cursor: pointer; border: none; transition: all 0.2s; }
        .btn-primary { background: var(--gold); color: var(--dark); }
        .btn-primary:hover { background: var(--gold-dark); }
        .btn-secondary { background: white; color: var(--text-primary); border: 1px solid rgba(0,0,0,0.1); }
        .btn-secondary:hover { background: var(--cream-light); }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        
        .card { background: white; border-radius: 16px; box-shadow: var(--shadow-sm); overflow: hidden; }
        .card-header { display: flex; justify-content: space-between; align-items: center; padding: 20px 24px; border-bottom: 1px solid rgba(0,0,0,0.05); }
        .card-title { font-size: 18px; color: var(--dark); }
        .card-body { padding: 24px; }
        
        .metrics-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px; margin-bottom: 32px; }
        .metric-card { background: white; border-radius: 16px; padding: 24px; box-shadow: var(--shadow-sm); }
        .metric-title { font-size: 13px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }
        .metric-value { font-size: 32px; font-weight: 700; color: var(--dark); }
        .metric-subtitle { font-size: 12px; color: var(--text-muted); margin-top: 4px; }
        
        .filter-bar { background: white; border-radius: 16px; padding: 24px; margin-bottom: 24px; box-shadow: var(--shadow-sm); }
        .filter-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; align-items: end; }
        .filter-group { display: flex; flex-direction: column; gap: 6px; }
        .filter-label { font-size: 12px; font-weight: 500; color: var(--text-secondary); }
        .filter-input, .filter-select { padding: 10px 14px; border: 1px solid rgba(0,0,0,0.1); border-radius: 6px; font-size: 14px; }
        .filter-input:focus, .filter-select:focus { outline: none; border-color: var(--gold); }
        
        .partner-card { display: flex; align-items: center; gap: 20px; padding: 20px; background: var(--cream-light); border-radius: 12px; margin-bottom: 12px; border-left: 4px solid var(--gold); }
        .partner-avatar { width: 60px; height: 60px; background: var(--gold); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; color: var(--dark); font-size: 20px; }
        .partner-details { flex: 1; }
        .partner-name { font-size: 16px; font-weight: 600; color: var(--dark); }
        .partner-email { font-size: 13px; color: var(--text-secondary); }
        .partner-stats { display: flex; gap: 24px; }
        .partner-stat { text-align: right; }
        .partner-stat-value { font-size: 16px; font-weight: 600; color: var(--dark); }
        .partner-stat-label { font-size: 11px; color: var(--text-muted); text-transform: uppercase; }
        .partner-badge { padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: 500; }
        .badge-weekly { background: rgba(23, 162, 184, 0.1); color: var(--info); }
        .badge-monthly { background: rgba(40, 167, 69, 0.1); color: var(--success); }
        .badge-annually { background: rgba(212, 175, 55, 0.1); color: var(--gold-dark); }
        
        .alert { padding: 14px 18px; border-radius: 6px; margin-bottom: 20px; }
        .alert-success { background: rgba(40, 167, 69, 0.1); color: var(--success); border: 1px solid rgba(40, 167, 69, 0.3); }
        .alert-warning { background: rgba(255, 193, 7, 0.1); color: #b7950b; border: 1px solid rgba(255, 193, 7, 0.3); }
        
        .top-contributor-item { display: flex; justify-content: space-between; align-items: center; padding: 12px; background: var(--cream-light); border-radius: 8px; margin-bottom: 8px; }
        
        .pagination { display: flex; justify-content: center; align-items: center; gap: 8px; margin-top: 24px; }
        .page-btn { padding: 8px 14px; border: 1px solid rgba(0,0,0,0.1); border-radius: 6px; background: white; cursor: pointer; font-size: 14px; }
        .page-btn:hover:not(:disabled) { background: var(--cream-light); border-color: var(--gold); }
        .page-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .page-btn.active { background: var(--gold); border-color: var(--gold); color: var(--dark); }
        
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0; }
            .filter-grid { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 768px) {
            .metrics-grid { grid-template-columns: repeat(2, 1fr); }
            .filter-grid { grid-template-columns: 1fr; }
            .partner-card { flex-direction: column; align-items: flex-start; }
            .partner-stats { width: 100%; display: flex; justify-content: space-between; margin-top: 12px; }
        }
    
        /* ── Responsive sidebar & hamburger ── */
        .sidebar { transition: transform 0.3s ease; }
        .sidebar.open { transform: translateX(0) !important; }

        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999;
        }
        .sidebar-overlay.active { display: block; }

        .hamburger {
            display: none;
            background: none;
            border: none;
            font-size: 22px;
            color: var(--dark, #0F1B2D);
            cursor: pointer;
            padding: 6px 10px;
            border-radius: 6px;
            line-height: 1;
            flex-shrink: 0;
        }
        .hamburger:hover { background: rgba(0,0,0,0.05); }

        .page-header-left {
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }

        @media (max-width: 1024px) {
            .hamburger { display: flex; align-items: center; justify-content: center; }
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0 !important; }
        }

        @media (max-width: 768px) {
            .main-content { padding: 16px !important; }
            .page-header { flex-wrap: wrap; gap: 12px; margin-bottom: 20px !important; }
            .page-actions { width: 100%; justify-content: flex-end; }
            .page-title h1 { font-size: 22px !important; }
            .metrics-grid { grid-template-columns: repeat(2, 1fr) !important; gap: 12px !important; }
            .filter-grid { grid-template-columns: 1fr !important; }
            .form-row { grid-template-columns: 1fr !important; }
            .metric-value { font-size: 24px !important; }
            .card-header, .card-body { padding: 16px !important; }
            .modal { width: 95% !important; border-radius: 12px !important; }
            .table-container { overflow-x: auto; }
            .btn-label { display: none; }
        }

        @media (max-width: 480px) {
            .metrics-grid { grid-template-columns: 1fr !important; }
            .main-content { padding: 12px !important; }
            .page-title h1 { font-size: 19px !important; }
        }

    </style>
</head>
<body>
    <div class="layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <div class="sidebar-logo-icon">✝</div>
                    <div class="sidebar-logo-text">
                        Bright Light Ministry Int'l
                        <span>Admin Dashboard</span>
                    </div>
                </div>
                <div class="admin-info">
                    <div class="admin-avatar"><?php echo strtoupper(substr($admin['first_name'], 0, 1) . substr($admin['last_name'], 0, 1)); ?></div>
                    <div class="admin-details">
                        <div class="admin-name"><?php echo e($admin['first_name'] . ' ' . $admin['last_name']); ?></div>
                        <div class="admin-email"><?php echo e($admin['email']); ?></div>
                    </div>
                </div>
            </div>
            <nav>
                <ul class="nav-menu">
                    <li class="nav-section">Dashboard</li>
                    <li class="nav-item"><a href="index.php" class="nav-link"><i class="fas fa-home"></i><span>Overview</span></a></li>
                    <li class="nav-section">Management</li>
                    <li class="nav-item"><a href="projects.php" class="nav-link"><i class="fas fa-project-diagram"></i><span>Projects</span></a></li>
                    <li class="nav-item"><a href="users.php" class="nav-link"><i class="fas fa-users"></i><span>Users</span></a></li>
                    <li class="nav-item"><a href="transactions.php" class="nav-link"><i class="fas fa-exchange-alt"></i><span>Transactions</span></a></li>
                    <li class="nav-item"><a href="plans.php" class="nav-link"><i class="fas fa-tags"></i><span>Payment Plans</span></a></li>
                    <li class="nav-item"><a href="partners.php" class="nav-link active"><i class="fas fa-handshake"></i><span>Partners</span></a></li>
                    <li class="nav-section">Administration</li>
                    <li class="nav-item"><a href="admin-members.php" class="nav-link"><i class="fas fa-user-shield"></i><span>Admin Members</span></a></li>
                    <li class="nav-item"><a href="audit-logs.php" class="nav-link"><i class="fas fa-history"></i><span>Audit Logs</span></a></li>
                    <li class="sidebar-footer">
                        <ul class="nav-menu">
                            <li class="nav-item"><a href="logout.php" class="nav-link"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <div class="page-header">
                <div class="page-header-left">
                    <button class="hamburger" onclick="toggleSidebar()" aria-label="Toggle menu"><i class="fas fa-bars"></i></button>
                    <div class="page-title">
                        <h1>Active Partners</h1>
                        <p>View and manage recurring payment contributors</p>
                    </div>
                </div>
                <div class="page-actions">
                    <a href="export.php?type=partners" class="btn btn-secondary">
                        <i class="fas fa-download"></i><span class="btn-label"> Export CSV</span>
                    </a>
                </div>
            </div>
            
            <!-- Statistics -->
            <div class="metrics-grid">
                <div class="metric-card">
                    <div class="metric-title">Total Partners</div>
                    <div class="metric-value"><?php echo number_format($stats['total']); ?></div>
                    <div class="metric-subtitle">Active pledges</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">Active Commitments</div>
                    <div class="metric-value"><?php echo number_format($stats['active']); ?></div>
                    <div class="metric-subtitle">Ongoing</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">Total Commitment</div>
                    <div class="metric-value"><?php echo formatCurrency($stats['total_commitment']); ?></div>
                    <div class="metric-subtitle">All pledges</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">Remaining</div>
                    <div class="metric-value"><?php echo formatCurrency($stats['remaining_commitment']); ?></div>
                    <div class="metric-subtitle">To be paid</div>
                </div>
            </div>
            
            <!-- Filter Bar -->
            <div class="filter-bar">
                <form method="GET" action="">
                    <div class="filter-grid">
                        <div class="filter-group">
                            <label class="filter-label">Frequency</label>
                            <select name="frequency" class="filter-select">
                                <option value="all" <?php echo $frequencyFilter === 'all' ? 'selected' : ''; ?>>All Frequencies</option>
                                <option value="Weekly" <?php echo $frequencyFilter === 'Weekly' ? 'selected' : ''; ?>>Weekly</option>
                                <option value="Monthly" <?php echo $frequencyFilter === 'Monthly' ? 'selected' : ''; ?>>Monthly</option>
                                <option value="Annually" <?php echo $frequencyFilter === 'Annually' ? 'selected' : ''; ?>>Annually</option>
                            </select>
                        </div>
                        <div class="filter-group">
                            <label class="filter-label">Status</label>
                            <select name="status" class="filter-select">
                                <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>All Status</option>
                                <option value="active" <?php echo $statusFilter === 'active' ? 'selected' : ''; ?>>Active</option>
                                <option value="completed" <?php echo $statusFilter === 'completed' ? 'selected' : ''; ?>>Completed</option>
                            </select>
                        </div>
                        <div class="filter-group">
                            <label class="filter-label">Min Amount</label>
                            <input type="number" name="min_amount" class="filter-input" placeholder="0" value="<?php echo e($minAmount); ?>">
                        </div>
                        <div class="filter-group">
                            <label class="filter-label">&nbsp;</label>
                            <button type="submit" class="btn btn-primary" style="width: 100%;">
                                <i class="fas fa-search"></i> Filter
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Partners List -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">Recurring Partners</h2>
                    <span style="color: var(--text-secondary); font-size: 14px;"><?php echo number_format($totalCount); ?> total records</span>
                </div>
                <div class="card-body">
                    <?php if (empty($partners)): ?>
                        <p style="color: var(--text-muted); text-align: center; padding: 40px;">No partners found matching your criteria.</p>
                    <?php else: ?>
                        <?php foreach ($partners as $partner): 
                            $badgeClass = 'badge-' . strtolower($partner['frequency']);
                        ?>
                            <div class="partner-card">
                                <div class="partner-avatar">
                                    <?php echo strtoupper(substr($partner['first_name'], 0, 1) . substr($partner['last_name'], 0, 1)); ?>
                                </div>
                                <div class="partner-details">
                                    <div class="partner-name"><?php echo e($partner['first_name'] . ' ' . $partner['last_name']); ?></div>
                                    <div class="partner-email"><?php echo e($partner['email']); ?><?php if ($partner['phone']): ?> • <?php echo e($partner['phone']); ?><?php endif; ?></div>
                                </div>
                                <div class="partner-stats">
                                    <div class="partner-stat">
                                        <div class="partner-stat-value"><?php echo formatCurrency($partner['total_amount']); ?></div>
                                        <div class="partner-stat-label">Total Pledge</div>
                                    </div>
                                    <div class="partner-stat">
                                        <div class="partner-stat-value"><?php echo formatCurrency($partner['remaining_amount']); ?></div>
                                        <div class="partner-stat-label">Remaining</div>
                                    </div>
                                    <div class="partner-stat">
                                        <div class="partner-stat-value"><?php echo number_format($partner['total_transactions']); ?></div>
                                        <div class="partner-stat-label">Transactions</div>
                                    </div>
                                    <div class="partner-stat">
                                        <div class="partner-stat-value"><?php echo formatCurrency($partner['total_given']); ?></div>
                                        <div class="partner-stat-label">Total Given</div>
                                    </div>
                                </div>
                                <div style="display: flex; flex-direction: column; gap: 8px; align-items: flex-end;">
                                    <span class="partner-badge <?php echo $badgeClass; ?>">
                                        <?php echo e($partner['frequency']); ?>
                                    </span>
                                    <small style="color: var(--text-muted);">
                                        <?php echo formatDate($partner['start_date']); ?>
                                        <?php if ($partner['end_date']): ?>
                                            - <?php echo formatDate($partner['end_date']); ?>
                                        <?php endif; ?>
                                    </small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    
                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <div class="pagination">
                            <button class="page-btn" onclick="goToPage(<?php echo $page - 1; ?>)" <?php echo $page <= 1 ? 'disabled' : ''; ?>>
                                <i class="fas fa-chevron-left"></i>
                            </button>
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <?php if ($i <= 5 || $i > $totalPages - 4 || abs($i - $page) <= 2): ?>
                                    <button class="page-btn <?php echo $i === $page ? 'active' : ''; ?>" onclick="goToPage(<?php echo $i; ?>)">
                                        <?php echo $i; ?>
                                    </button>
                                <?php elseif (abs($i - $page) <= 2): ?>
                                    <button class="page-btn" disabled>...</button>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <button class="page-btn" onclick="goToPage(<?php echo $page + 1; ?>)" <?php echo $page >= $totalPages ? 'disabled' : ''; ?>>
                                <i class="fas fa-chevron-right"></i>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Top Contributors -->
            <div class="card" style="margin-top: 24px;">
                <div class="card-header">
                    <h2 class="card-title">Top Contributors</h2>
                </div>
                <div class="card-body">
                    <?php foreach ($topContributors as $contributor): ?>
                        <div class="top-contributor-item">
                            <div>
                                <strong><?php echo e($contributor['first_name'] . ' ' . $contributor['last_name']); ?></strong>
                                <br><small style="color: var(--text-secondary);"><?php echo e($contributor['email']); ?></small>
                            </div>
                            <div style="text-align: right;">
                                <div style="font-weight: 600; color: var(--success);"><?php echo formatCurrency($contributor['total_given']); ?></div>
                                <small style="color: var(--text-muted);"><?php echo $contributor['active_pledges']; ?> active pledge(s)</small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- Upcoming Renewals -->
            <?php if (!empty($upcomingRenewals)): ?>
            <div class="card" style="margin-top: 24px;">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-exclamation-circle" style="color: var(--warning);"></i>
                        Upcoming Pledge Endings (Next 30 Days)
                    </h2>
                </div>
                <div class="card-body">
                    <?php foreach ($upcomingRenewals as $renewal): ?>
                        <div class="alert alert-warning" style="margin-bottom: 12px;">
                            <strong><?php echo e($renewal['first_name'] . ' ' . $renewal['last_name']); ?></strong>
                            <span style="margin: 0 12px;">•</span>
                            <?php echo e($renewal['frequency']); ?> pledge
                            <span style="margin: 0 12px;">•</span>
                            Ends: <?php echo formatDate($renewal['end_date']); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </main>
    </div>
    
    <script>
        function goToPage(page) {
            const params = new URLSearchParams(window.location.search);
            params.set('page', page);
            window.location.search = params.toString();
        }
        
        function viewReceipt(ref) {
            window.open('api/receipt.php?ref=' + encodeURIComponent(ref), '_blank');
        }
    </script>

    <!-- Responsive sidebar JS -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>
    <script>
        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('open');
            document.getElementById('sidebarOverlay').classList.toggle('active');
        }
        function closeSidebar() {
            document.querySelector('.sidebar').classList.remove('open');
            document.getElementById('sidebarOverlay').classList.remove('active');
        }
        document.querySelectorAll('.nav-link').forEach(function(link) {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 1024) closeSidebar();
            });
        });
    </script>

</body>
</html>
